import { 
  users, User, InsertUser,
  products, Product, InsertProduct,
  cartItems, CartItem, InsertCartItem,
  orders, Order, InsertOrder,
  orderItems, OrderItem, InsertOrderItem,
  reviews, Review, InsertReview,
  otps, Otp, InsertOtp,
  tokens, Token, InsertToken
} from "@shared/schema";
import { recommendationEngine } from "./ai-recommendation";

// Storage interface for all CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined>;

  // Product operations
  getProduct(id: number): Promise<Product | undefined>;
  getProducts(options?: {
    category?: string;
    minPrice?: number;
    maxPrice?: number;
    sellerId?: number;
    limit?: number;
    offset?: number;
  }): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, data: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Cart operations
  getCartItems(userId: number): Promise<CartItem[]>;
  getCartItem(id: number): Promise<CartItem | undefined>;
  getCartItemByProductAndUser(productId: number, userId: number): Promise<CartItem | undefined>;
  createCartItem(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, data: Partial<InsertCartItem>): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;
  clearCart(userId: number): Promise<boolean>;

  // Order operations
  getOrder(id: number): Promise<Order | undefined>;
  getOrders(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;

  // Order items operations
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;

  // Review operations
  getReviews(productId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;

  // OTP operations
  createOtp(otp: InsertOtp): Promise<Otp>;
  verifyOtp(phone: string, code: string): Promise<boolean>;

  // Token operations
  createToken(token: InsertToken): Promise<Token>;
  getTokenByValue(token: string): Promise<Token | undefined>;
  deleteToken(token: string): Promise<boolean>;
  
  // AI Recommendation operations
  getRecommendedProducts(userId: number, count?: number, excludeProductIds?: number[]): Promise<Product[]>;
  getSimilarProducts(productId: number, count?: number): Promise<Product[]>;
  recordProductView(userId: number, productId: number): Promise<void>;
  recordProductPurchase(userId: number, productId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private reviews: Map<number, Review>;
  private otps: Map<number, Otp>;
  private tokens: Map<number, Token>;
  
  private userId: number = 1;
  private productId: number = 1;
  private cartItemId: number = 1;
  private orderId: number = 1;
  private orderItemId: number = 1;
  private reviewId: number = 1;
  private otpId: number = 1;
  private tokenId: number = 1;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.reviews = new Map();
    this.otps = new Map();
    this.tokens = new Map();
    
    // Add some initial eco-friendly products
    this.createProduct({
      name: "Bamboo Toothbrush Set",
      description: "Eco-friendly bamboo toothbrushes with charcoal-infused bristles for a natural clean.",
      price: 12.99,
      imageUrl: "https://images.unsplash.com/photo-1564419320408-38e24e038739",
      category: "Zero Waste",
      sellerId: 1,
      stock: 100,
      ecoRating: 5,
      ecoDescription: "100% biodegradable bamboo handles and plant-based bristles, plastic-free packaging."
    });
    
    this.createProduct({
      name: "Reusable Produce Bags",
      description: "Set of 5 mesh produce bags for grocery shopping. Say no to plastic!",
      price: 15.99,
      imageUrl: "https://images.unsplash.com/photo-1570913196376-dacb677ef459",
      category: "Eco Packaging",
      sellerId: 1,
      stock: 50,
      ecoRating: 5,
      ecoDescription: "Made from recycled PET bottles, machine washable and durable for years of use."
    });
    
    this.createProduct({
      name: "Organic Cotton Bedding Set",
      description: "Luxurious bedding set made from 100% organic cotton. Queen size, includes sheets and pillowcases.",
      price: 89.99,
      imageUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f",
      category: "Sustainable Home",
      sellerId: 1,
      stock: 25,
      ecoRating: 4,
      ecoDescription: "GOTS certified organic cotton, grown without harmful pesticides or chemicals."
    });
    
    this.createProduct({
      name: "Solar-Powered Garden Lights",
      description: "Pack of 6 solar path lights for your garden or walkway. No electricity needed!",
      price: 34.99,
      imageUrl: "https://images.unsplash.com/photo-1480074568708-e7b720bb3f09",
      category: "Energy Efficient",
      sellerId: 1,
      stock: 30,
      ecoRating: 4,
      ecoDescription: "Harnesses solar energy, auto on/off feature, made with recyclable materials."
    });
    
    this.createProduct({
      name: "Beeswax Food Wraps",
      description: "Set of 3 reusable food wraps in different sizes. A sustainable alternative to plastic wrap.",
      price: 18.99,
      imageUrl: "https://images.unsplash.com/photo-1591130901969-2a1bfafb2ee2",
      category: "Eco-Friendly Kitchen",
      sellerId: 1,
      stock: 45,
      ecoRating: 5,
      ecoDescription: "Handmade with organic cotton, local beeswax, jojoba oil and tree resin. Washable and reusable for up to a year."
    });
    
    // Create default admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      email: "admin@ecoshop.com",
      phone: "1234567890",
      fullName: "Admin User",
      isSeller: true,
      isAdmin: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.phone === phone
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Product operations
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProducts(options: {
    category?: string;
    minPrice?: number;
    maxPrice?: number;
    sellerId?: number;
    limit?: number;
    offset?: number;
  } = {}): Promise<Product[]> {
    let filteredProducts = Array.from(this.products.values());
    
    if (options.category) {
      filteredProducts = filteredProducts.filter(
        product => product.category === options.category
      );
    }
    
    if (options.minPrice !== undefined) {
      filteredProducts = filteredProducts.filter(
        product => product.price >= options.minPrice!
      );
    }
    
    if (options.maxPrice !== undefined) {
      filteredProducts = filteredProducts.filter(
        product => product.price <= options.maxPrice!
      );
    }
    
    if (options.sellerId) {
      filteredProducts = filteredProducts.filter(
        product => product.sellerId === options.sellerId
      );
    }
    
    // Sort by newest first
    filteredProducts.sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    
    // Apply pagination
    if (options.offset !== undefined && options.limit !== undefined) {
      filteredProducts = filteredProducts.slice(
        options.offset,
        options.offset + options.limit
      );
    } else if (options.limit !== undefined) {
      filteredProducts = filteredProducts.slice(0, options.limit);
    }
    
    return filteredProducts;
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const createdAt = new Date();
    const product: Product = { ...insertProduct, id, createdAt };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, data: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { ...product, ...data };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  // Cart operations
  async getCartItems(userId: number): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      item => item.userId === userId
    );
  }

  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }

  async getCartItemByProductAndUser(productId: number, userId: number): Promise<CartItem | undefined> {
    return Array.from(this.cartItems.values()).find(
      item => item.productId === productId && item.userId === userId
    );
  }

  async createCartItem(insertCartItem: InsertCartItem): Promise<CartItem> {
    const id = this.cartItemId++;
    const createdAt = new Date();
    const cartItem: CartItem = { ...insertCartItem, id, createdAt };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: number, data: Partial<InsertCartItem>): Promise<CartItem | undefined> {
    const cartItem = this.cartItems.get(id);
    if (!cartItem) return undefined;
    
    const updatedCartItem = { ...cartItem, ...data };
    this.cartItems.set(id, updatedCartItem);
    return updatedCartItem;
  }

  async deleteCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(userId: number): Promise<boolean> {
    const userCartItems = Array.from(this.cartItems.values()).filter(
      item => item.userId === userId
    );
    
    userCartItems.forEach(item => {
      this.cartItems.delete(item.id);
    });
    
    return true;
  }

  // Order operations
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      order => order.userId === userId
    ).sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderId++;
    const createdAt = new Date();
    const order: Order = { ...insertOrder, id, createdAt };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Order items operations
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(
      item => item.orderId === orderId
    );
  }

  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemId++;
    const orderItem: OrderItem = { ...insertOrderItem, id };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }

  // Review operations
  async getReviews(productId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      review => review.productId === productId
    ).sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.reviewId++;
    const createdAt = new Date();
    const review: Review = { ...insertReview, id, createdAt };
    this.reviews.set(id, review);
    return review;
  }

  // OTP operations
  async createOtp(insertOtp: InsertOtp): Promise<Otp> {
    const id = this.otpId++;
    const verified = false;
    const otp: Otp = { ...insertOtp, id, verified };
    this.otps.set(id, otp);
    return otp;
  }

  async verifyOtp(phone: string, code: string): Promise<boolean> {
    const otp = Array.from(this.otps.values()).find(
      o => o.phone === phone && o.code === code && new Date(o.expiresAt) > new Date() && !o.verified
    );
    
    if (!otp) return false;
    
    // Mark OTP as verified
    const updatedOtp = { ...otp, verified: true };
    this.otps.set(otp.id, updatedOtp);
    
    return true;
  }

  // Token operations
  async createToken(insertToken: InsertToken): Promise<Token> {
    const id = this.tokenId++;
    const token: Token = { ...insertToken, id };
    this.tokens.set(id, token);
    return token;
  }

  async getTokenByValue(tokenValue: string): Promise<Token | undefined> {
    return Array.from(this.tokens.values()).find(
      t => t.token === tokenValue && new Date(t.expiresAt) > new Date()
    );
  }

  async deleteToken(tokenValue: string): Promise<boolean> {
    const token = Array.from(this.tokens.values()).find(
      t => t.token === tokenValue
    );
    
    if (!token) return false;
    
    return this.tokens.delete(token.id);
  }
  
  // AI Recommendation operations
  async getRecommendedProducts(userId: number, count: number = 5, excludeProductIds: number[] = []): Promise<Product[]> {
    const allProducts = Array.from(this.products.values());
    
    // If there aren't enough products, just return what we have
    if (allProducts.length <= excludeProductIds.length) {
      return allProducts.filter(p => !excludeProductIds.includes(p.id));
    }
    
    // Use the recommendation engine to generate personalized recommendations
    return recommendationEngine.generateRecommendations(userId, allProducts, count, excludeProductIds);
  }
  
  async getSimilarProducts(productId: number, count: number = 4): Promise<Product[]> {
    const allProducts = Array.from(this.products.values());
    const product = this.products.get(productId);
    
    if (!product) {
      return [];
    }
    
    // Use the recommendation engine to find similar products
    return recommendationEngine.getSimilarProducts(productId, allProducts, count);
  }
  
  async recordProductView(userId: number, productId: number): Promise<void> {
    const product = this.products.get(productId);
    if (!product || !userId) return;
    
    // Record the view in the recommendation engine
    recommendationEngine.recordProductView(userId, product);
  }
  
  async recordProductPurchase(userId: number, productId: number): Promise<void> {
    const product = this.products.get(productId);
    if (!product || !userId) return;
    
    // Record the purchase in the recommendation engine
    recommendationEngine.recordPurchase(userId, product);
  }
}

export const storage = new MemStorage();
