import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, loginSchema, insertProductSchema, 
  insertCartItemSchema, insertOrderSchema, insertOrderItemSchema,
  insertReviewSchema, verifyOtpSchema, productCategories
} from "@shared/schema";
import { randomBytes } from "crypto";
import session from "express-session";
import MemoryStore from "memorystore";

const generateToken = () => randomBytes(48).toString("hex");
const generateOtp = () => Math.floor(100000 + Math.random() * 900000).toString();

// One day in milliseconds for expiration
const ONE_DAY = 24 * 60 * 60 * 1000;

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session management
  const SessionStore = MemoryStore(session);
  app.use(
    session({
      secret: "eco-marketplace-secret",
      resave: false,
      saveUninitialized: false,
      store: new SessionStore({
        checkPeriod: ONE_DAY,
      }),
      cookie: {
        maxAge: ONE_DAY,
      },
    })
  );

  // Authentication middleware
  const authenticate = async (req: Request, res: Response, next: any) => {
    if (req.session.userId) {
      const user = await storage.getUser(req.session.userId);
      if (user) {
        req.user = user;
        return next();
      }
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Register API routes
  app.get("/api/health", (req, res) => {
    res.status(200).json({ status: "healthy" });
  });

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const result = insertUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.message });
      }

      const { username, email, phone } = result.data;

      // Check if username already exists
      if (username) {
        const existingUser = await storage.getUserByUsername(username);
        if (existingUser) {
          return res.status(400).json({ message: "Username already exists" });
        }
      }

      // Check if email already exists
      if (email) {
        const existingUser = await storage.getUserByEmail(email);
        if (existingUser) {
          return res.status(400).json({ message: "Email already exists" });
        }
      }

      // Check if phone already exists
      if (phone) {
        const existingUser = await storage.getUserByPhone(phone);
        if (existingUser) {
          return res.status(400).json({ message: "Phone already exists" });
        }
      }

      const user = await storage.createUser(result.data);
      
      // Set session
      req.session.userId = user.id;
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to register user" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const result = loginSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.message });
      }

      const { username, email, phone, password } = result.data;
      let user;

      // Find user by username, email, or phone
      if (username) {
        user = await storage.getUserByUsername(username);
      } else if (email) {
        user = await storage.getUserByEmail(email);
      } else if (phone) {
        user = await storage.getUserByPhone(phone);
      }

      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Set session
      req.session.userId = user.id;
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to log in" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to log out" });
      }
      res.clearCookie("connect.sid");
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", authenticate, (req, res) => {
    const { password, ...userWithoutPassword } = req.user;
    res.status(200).json(userWithoutPassword);
  });

  // OTP routes
  app.post("/api/auth/request-otp", async (req, res) => {
    try {
      const { phone } = req.body;
      
      if (!phone) {
        return res.status(400).json({ message: "Phone number is required" });
      }

      // Generate OTP
      const code = generateOtp();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      // Save OTP
      await storage.createOtp({
        phone,
        code,
        expiresAt,
      });

      // In a real application, send the OTP via SMS
      // For this demo, we're returning it in the response
      res.status(200).json({ 
        message: "OTP sent successfully",
        code // This would not be returned in production
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to send OTP" });
    }
  });

  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      const result = verifyOtpSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.message });
      }

      const { phone, code } = result.data;
      const verified = await storage.verifyOtp(phone, code);

      if (!verified) {
        return res.status(400).json({ message: "Invalid or expired OTP" });
      }

      // Find user by phone or create a new one
      let user = await storage.getUserByPhone(phone);
      
      if (!user) {
        // This is a simplified approach - in a real app you'd collect more info
        user = await storage.createUser({
          username: `user_${Date.now()}`,
          phone,
          password: "", // Empty password since auth is via OTP
        });
      }

      // Set session
      req.session.userId = user.id;
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to verify OTP" });
    }
  });

  // User profile routes
  app.put("/api/users/profile", authenticate, async (req, res) => {
    try {
      const userId = req.user.id;
      const updateData = req.body;
      
      // Don't allow changing username, email, or phone to existing values
      if (updateData.username) {
        const existingUser = await storage.getUserByUsername(updateData.username);
        if (existingUser && existingUser.id !== userId) {
          return res.status(400).json({ message: "Username already exists" });
        }
      }
      
      if (updateData.email) {
        const existingUser = await storage.getUserByEmail(updateData.email);
        if (existingUser && existingUser.id !== userId) {
          return res.status(400).json({ message: "Email already exists" });
        }
      }
      
      if (updateData.phone) {
        const existingUser = await storage.getUserByPhone(updateData.phone);
        if (existingUser && existingUser.id !== userId) {
          return res.status(400).json({ message: "Phone already exists" });
        }
      }
      
      const updatedUser = await storage.updateUser(userId, updateData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const { 
        category, 
        minPrice, 
        maxPrice, 
        sellerId,
        limit = 20,
        offset = 0
      } = req.query;
      
      const options: any = {
        limit: parseInt(limit as string),
        offset: parseInt(offset as string)
      };
      
      if (category) options.category = category as string;
      if (minPrice) options.minPrice = parseFloat(minPrice as string);
      if (maxPrice) options.maxPrice = parseFloat(maxPrice as string);
      if (sellerId) options.sellerId = parseInt(sellerId as string);
      
      const products = await storage.getProducts(options);
      
      // Log product view for recommendations if user is authenticated
      if (req.session.userId && req.query.productId) {
        const productId = parseInt(req.query.productId as string);
        if (!isNaN(productId)) {
          await storage.recordProductView(req.session.userId, productId);
        }
      }
      
      res.status(200).json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });
  
  // AI Recommendation Routes
  app.get("/api/recommendations", authenticate, async (req, res) => {
    try {
      const userId = req.user.id;
      const count = req.query.count ? parseInt(req.query.count as string) : 5;
      const excludeIds = req.query.exclude ? 
        (req.query.exclude as string).split(',').map(id => parseInt(id)) : 
        [];
      
      const recommendations = await storage.getRecommendedProducts(userId, count, excludeIds);
      res.status(200).json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to get recommendations" });
    }
  });
  
  app.get("/api/products/:id/similar", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const count = req.query.count ? parseInt(req.query.count as string) : 4;
      
      const similarProducts = await storage.getSimilarProducts(productId, count);
      res.status(200).json(similarProducts);
    } catch (error) {
      res.status(500).json({ message: "Failed to find similar products" });
    }
  });

  app.get("/api/products/categories", async (req, res) => {
    try {
      res.status(200).json(productCategories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.status(200).json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", authenticate, async (req, res) => {
    try {
      // Check if user is a seller
      if (!req.user.isSeller) {
        return res.status(403).json({ message: "Only sellers can create products" });
      }
      
      const result = insertProductSchema.safeParse({
        ...req.body,
        sellerId: req.user.id
      });
      
      if (!result.success) {
        return res.status(400).json({ message: result.error.message });
      }
      
      const product = await storage.createProduct(result.data);
      res.status(201).json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.put("/api/products/:id", authenticate, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Check if user is the seller of the product
      if (product.sellerId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "Unauthorized to update this product" });
      }
      
      const updatedProduct = await storage.updateProduct(productId, req.body);
      res.status(200).json(updatedProduct);
    } catch (error) {
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", authenticate, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Check if user is the seller of the product
      if (product.sellerId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "Unauthorized to delete this product" });
      }
      
      await storage.deleteProduct(productId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Cart routes
  app.get("/api/cart", authenticate, async (req, res) => {
    try {
      const userId = req.user.id;
      const cartItems = await storage.getCartItems(userId);
      
      // Get product details for each cart item
      const cartWithProducts = await Promise.all(
        cartItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      res.status(200).json(cartWithProducts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cart items" });
    }
  });

  app.post("/api/cart", authenticate, async (req, res) => {
    try {
      const userId = req.user.id;
      const result = insertCartItemSchema.safeParse({
        ...req.body,
        userId
      });
      
      if (!result.success) {
        return res.status(400).json({ message: result.error.message });
      }
      
      const { productId, quantity } = result.data;
      
      // Check if product exists
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Check if product is in stock
      if (product.stock < quantity) {
        return res.status(400).json({ message: "Not enough stock available" });
      }
      
      // Check if item already in cart
      const existingItem = await storage.getCartItemByProductAndUser(productId, userId);
      
      if (existingItem) {
        // Update quantity if already in cart
        const updatedItem = await storage.updateCartItem(existingItem.id, {
          quantity: existingItem.quantity + quantity
        });
        
        // Get product details
        return res.status(200).json({
          ...updatedItem,
          product
        });
      }
      
      // Add new item to cart
      const cartItem = await storage.createCartItem(result.data);
      
      // Return with product details
      res.status(201).json({
        ...cartItem,
        product
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to add item to cart" });
    }
  });

  app.put("/api/cart/:id", authenticate, async (req, res) => {
    try {
      const itemId = parseInt(req.params.id);
      const userId = req.user.id;
      const { quantity } = req.body;
      
      if (!quantity || quantity <= 0) {
        return res.status(400).json({ message: "Quantity must be greater than 0" });
      }
      
      const cartItem = await storage.getCartItem(itemId);
      
      if (!cartItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      // Check if user owns the cart item
      if (cartItem.userId !== userId) {
        return res.status(403).json({ message: "Unauthorized to update this cart item" });
      }
      
      // Check if product exists and has enough stock
      const product = await storage.getProduct(cartItem.productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      if (product.stock < quantity) {
        return res.status(400).json({ message: "Not enough stock available" });
      }
      
      const updatedItem = await storage.updateCartItem(itemId, { quantity });
      
      // Return with product details
      res.status(200).json({
        ...updatedItem,
        product
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to update cart item" });
    }
  });

  app.delete("/api/cart/:id", authenticate, async (req, res) => {
    try {
      const itemId = parseInt(req.params.id);
      const userId = req.user.id;
      
      const cartItem = await storage.getCartItem(itemId);
      
      if (!cartItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      // Check if user owns the cart item
      if (cartItem.userId !== userId) {
        return res.status(403).json({ message: "Unauthorized to delete this cart item" });
      }
      
      await storage.deleteCartItem(itemId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove item from cart" });
    }
  });

  app.delete("/api/cart", authenticate, async (req, res) => {
    try {
      const userId = req.user.id;
      await storage.clearCart(userId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to clear cart" });
    }
  });

  // Order routes
  app.get("/api/orders", authenticate, async (req, res) => {
    try {
      const userId = req.user.id;
      const orders = await storage.getOrders(userId);
      
      // Get order items for each order
      const ordersWithItems = await Promise.all(
        orders.map(async (order) => {
          const items = await storage.getOrderItems(order.id);
          
          // Get product details for each item
          const itemsWithProducts = await Promise.all(
            items.map(async (item) => {
              const product = await storage.getProduct(item.productId);
              return {
                ...item,
                product
              };
            })
          );
          
          return {
            ...order,
            items: itemsWithProducts
          };
        })
      );
      
      res.status(200).json(ordersWithItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", authenticate, async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const userId = req.user.id;
      
      const order = await storage.getOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if user owns the order
      if (order.userId !== userId && !req.user.isAdmin) {
        return res.status(403).json({ message: "Unauthorized to view this order" });
      }
      
      // Get order items
      const items = await storage.getOrderItems(orderId);
      
      // Get product details for each item
      const itemsWithProducts = await Promise.all(
        items.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      res.status(200).json({
        ...order,
        items: itemsWithProducts
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.post("/api/orders", authenticate, async (req, res) => {
    try {
      const userId = req.user.id;
      const { totalAmount, paymentMethod, shippingAddress } = req.body;
      
      if (!totalAmount || !paymentMethod || !shippingAddress) {
        return res.status(400).json({ 
          message: "Total amount, payment method, and shipping address are required" 
        });
      }
      
      // Get cart items
      const cartItems = await storage.getCartItems(userId);
      
      if (cartItems.length === 0) {
        return res.status(400).json({ message: "Cart is empty" });
      }
      
      // Verify each cart item has enough stock
      for (const item of cartItems) {
        const product = await storage.getProduct(item.productId);
        if (!product) {
          return res.status(404).json({ 
            message: `Product with ID ${item.productId} not found` 
          });
        }
        
        if (product.stock < item.quantity) {
          return res.status(400).json({ 
            message: `Not enough stock for ${product.name}` 
          });
        }
      }
      
      // Create order
      const order = await storage.createOrder({
        userId,
        totalAmount,
        paymentMethod,
        shippingAddress,
        status: "pending"
      });
      
      // Create order items
      const orderItems = await Promise.all(
        cartItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          
          // Create order item
          const orderItem = await storage.createOrderItem({
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            price: product!.price
          });
          
          // Update product stock
          await storage.updateProduct(item.productId, {
            stock: product!.stock - item.quantity
          });
          
          return {
            ...orderItem,
            product
          };
        })
      );
      
      // Clear cart
      await storage.clearCart(userId);
      
      res.status(201).json({
        ...order,
        items: orderItems
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  // Review routes
  app.get("/api/products/:id/reviews", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      
      // Check if product exists
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      const reviews = await storage.getReviews(productId);
      
      // Get user info for each review
      const reviewsWithUsers = await Promise.all(
        reviews.map(async (review) => {
          const user = await storage.getUser(review.userId);
          return {
            ...review,
            user: user ? {
              id: user.id,
              username: user.username,
              fullName: user.fullName,
            } : null
          };
        })
      );
      
      res.status(200).json(reviewsWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post("/api/products/:id/reviews", authenticate, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const userId = req.user.id;
      
      // Check if product exists
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      const result = insertReviewSchema.safeParse({
        ...req.body,
        productId,
        userId
      });
      
      if (!result.success) {
        return res.status(400).json({ message: result.error.message });
      }
      
      const review = await storage.createReview(result.data);
      
      // Return with user info
      res.status(201).json({
        ...review,
        user: {
          id: req.user.id,
          username: req.user.username,
          fullName: req.user.fullName,
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // AI Product Recommendations (simulated)
  app.get("/api/recommendations", async (req, res) => {
    try {
      const { userId, productId, limit = 5 } = req.query;
      
      // In a real implementation, this would use a trained model
      // For this demo, we're just returning a similar category
      let recommendedProducts: any[] = [];
      
      if (productId) {
        // Recommendations based on product
        const product = await storage.getProduct(parseInt(productId as string));
        if (product) {
          // Get products from the same category
          recommendedProducts = await storage.getProducts({
            category: product.category,
            limit: parseInt(limit as string) + 1,
          });
          
          // Filter out the original product
          recommendedProducts = recommendedProducts.filter(p => p.id !== product.id);
        }
      } else if (userId) {
        // Recommendations based on user behavior
        // In a real app, we'd use order history and browsing data
        recommendedProducts = await storage.getProducts({
          limit: parseInt(limit as string),
        });
      } else {
        // General recommendations
        recommendedProducts = await storage.getProducts({
          limit: parseInt(limit as string),
        });
      }
      
      // Limit to requested number
      recommendedProducts = recommendedProducts.slice(0, parseInt(limit as string));
      
      res.status(200).json(recommendedProducts);
    } catch (error) {
      res.status(500).json({ message: "Failed to get recommendations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
