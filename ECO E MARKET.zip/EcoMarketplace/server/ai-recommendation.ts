import { Product } from "@shared/schema";

// This is a simplified AI recommendation model for demonstration purposes
// In a real-world scenario, you would use a more sophisticated algorithm or a machine learning model
export class RecommendationEngine {
  // Store user browsing and purchase history
  private userHistory: Map<number, {
    viewedProducts: Map<number, number>;  // productId -> view count
    purchasedProducts: Set<number>;       // productId
    categories: Map<string, number>;      // category -> interaction count
    ecoPreferences: Map<string, number>;  // eco feature -> preference score
  }>;

  // Store product similarity matrix
  private productSimilarity: Map<number, Map<number, number>>;

  constructor() {
    this.userHistory = new Map();
    this.productSimilarity = new Map();
  }

  // Initialize user history if not exists
  private initUserHistory(userId: number) {
    if (!this.userHistory.has(userId)) {
      this.userHistory.set(userId, {
        viewedProducts: new Map(),
        purchasedProducts: new Set(),
        categories: new Map(),
        ecoPreferences: new Map()
      });
    }
    return this.userHistory.get(userId)!;
  }

  // Record product view event
  public recordProductView(userId: number, product: Product) {
    const userHistory = this.initUserHistory(userId);
    
    // Update viewed products
    const currentViews = userHistory.viewedProducts.get(product.id) || 0;
    userHistory.viewedProducts.set(product.id, currentViews + 1);
    
    // Update category preference
    const categoryCount = userHistory.categories.get(product.category) || 0;
    userHistory.categories.set(product.category, categoryCount + 1);
    
    // Update eco preferences based on product attributes
    this.updateEcoPreferences(userId, product);
  }

  // Record product purchase event
  public recordPurchase(userId: number, product: Product) {
    const userHistory = this.initUserHistory(userId);
    
    // Add to purchased products
    userHistory.purchasedProducts.add(product.id);
    
    // Increase category preference more significantly for purchases
    const categoryCount = userHistory.categories.get(product.category) || 0;
    userHistory.categories.set(product.category, categoryCount + 3);
    
    // Update eco preferences with higher weight for purchased products
    this.updateEcoPreferences(userId, product, 2);
  }

  // Update eco preferences based on product attributes
  private updateEcoPreferences(userId: number, product: Product, weight: number = 1) {
    const userHistory = this.initUserHistory(userId);
    
    // Example eco attributes (these would come from the product in a real system)
    if (product.ecoRating > 3) {
      const highRatingPref = userHistory.ecoPreferences.get('highEcoRating') || 0;
      userHistory.ecoPreferences.set('highEcoRating', highRatingPref + weight);
    }
    
    // Other eco attributes could be processed here based on product data
    // For example: organic, recyclable, biodegradable, etc.
  }

  // Calculate product similarity based on product attributes
  public calculateProductSimilarity(products: Product[]) {
    // Reset similarity matrix
    this.productSimilarity = new Map();
    
    // Compare each product with all others
    for (let i = 0; i < products.length; i++) {
      const productA = products[i];
      const similarityMap = new Map<number, number>();
      
      for (let j = 0; j < products.length; j++) {
        if (i === j) continue; // Skip self comparison
        
        const productB = products[j];
        let similarity = 0;
        
        // Calculate similarity based on various factors
        
        // Category similarity
        if (productA.category === productB.category) {
          similarity += 0.3;
        }
        
        // Price similarity (inverted distance)
        const priceDiff = Math.abs(productA.price - productB.price);
        const maxPrice = Math.max(...products.map(p => p.price));
        similarity += 0.2 * (1 - (priceDiff / maxPrice));
        
        // Eco rating similarity
        const ratingDiff = Math.abs(productA.ecoRating - productB.ecoRating);
        similarity += 0.4 * (1 - (ratingDiff / 5)); // Assuming rating is out of 5
        
        // Additional factors could be considered here
        
        similarityMap.set(productB.id, similarity);
      }
      
      this.productSimilarity.set(productA.id, similarityMap);
    }
  }

  // Generate personalized recommendations for a user
  public generateRecommendations(
    userId: number,
    products: Product[],
    count: number = 5,
    excludeProductIds: number[] = []
  ): Product[] {
    const userHistory = this.userHistory.get(userId);
    
    // If no history, return top eco-rated products
    if (!userHistory) {
      return this.getTopEcoRatedProducts(products, count, excludeProductIds);
    }
    
    // Calculate a score for each product
    const productScores = new Map<number, number>();
    
    for (const product of products) {
      // Skip products to exclude
      if (excludeProductIds.includes(product.id)) {
        continue;
      }
      
      // Skip already purchased products
      if (userHistory.purchasedProducts.has(product.id)) {
        continue;
      }
      
      let score = 0;
      
      // Factor 1: Category preference
      const categoryPreference = userHistory.categories.get(product.category) || 0;
      score += categoryPreference * 0.3;
      
      // Factor 2: Eco rating aligned with user preferences
      if (product.ecoRating > 3 && (userHistory.ecoPreferences.get('highEcoRating') || 0) > 0) {
        score += 0.4 * product.ecoRating * (userHistory.ecoPreferences.get('highEcoRating') || 0);
      }
      
      // Factor 3: Similar to products the user has interacted with
      for (const [viewedId, viewCount] of userHistory.viewedProducts.entries()) {
        const similarity = this.productSimilarity.get(viewedId)?.get(product.id) || 0;
        score += similarity * viewCount * 0.2;
      }
      
      // Factor 4: Base score from product's eco rating
      score += product.ecoRating * 0.1;
      
      productScores.set(product.id, score);
    }
    
    // Sort products by score and return top N
    const sortedProducts = products
      .filter(p => productScores.has(p.id))
      .sort((a, b) => {
        return (productScores.get(b.id) || 0) - (productScores.get(a.id) || 0);
      })
      .slice(0, count);
    
    // If we don't have enough recommendations, pad with top eco-rated products
    if (sortedProducts.length < count) {
      const topEcoProducts = this.getTopEcoRatedProducts(
        products, 
        count - sortedProducts.length, 
        [...excludeProductIds, ...sortedProducts.map(p => p.id)]
      );
      return [...sortedProducts, ...topEcoProducts];
    }
    
    return sortedProducts;
  }

  // Get top eco-rated products (fallback recommendation strategy)
  private getTopEcoRatedProducts(
    products: Product[],
    count: number,
    excludeProductIds: number[] = []
  ): Product[] {
    return products
      .filter(p => !excludeProductIds.includes(p.id))
      .sort((a, b) => b.ecoRating - a.ecoRating)
      .slice(0, count);
  }

  // Get similar products to a specific product
  public getSimilarProducts(
    productId: number,
    products: Product[],
    count: number = 4
  ): Product[] {
    const similarityMap = this.productSimilarity.get(productId);
    
    if (!similarityMap) {
      // If no similarity data, return products in same category
      const currentProduct = products.find(p => p.id === productId);
      if (!currentProduct) return [];
      
      return products
        .filter(p => p.id !== productId && p.category === currentProduct.category)
        .sort((a, b) => b.ecoRating - a.ecoRating)
        .slice(0, count);
    }
    
    // Get product IDs sorted by similarity score
    const similarProductIds = [...similarityMap.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(entry => entry[0])
      .slice(0, count);
    
    // Map back to actual product objects
    return similarProductIds
      .map(id => products.find(p => p.id === id))
      .filter((p): p is Product => p !== undefined);
  }

  // Reset all user data (for demo/testing purposes)
  public resetData() {
    this.userHistory.clear();
    this.productSimilarity.clear();
  }
}

// Create a singleton instance
export const recommendationEngine = new RecommendationEngine();