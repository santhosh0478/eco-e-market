import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import ProductGrid from "@/components/product/ProductGrid";
import ProductFilter from "@/components/product/ProductFilter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Filter, X, Search } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const Buy = () => {
  const [location] = useLocation();
  const [searchParams, setSearchParams] = useState<URLSearchParams>(
    typeof window !== "undefined" ? new URLSearchParams(window.location.search) : new URLSearchParams()
  );
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState(searchParams.get("search") || "");
  const [appliedFilters, setAppliedFilters] = useState({
    category: searchParams.get("category") || undefined,
    minPrice: searchParams.get("minPrice") ? parseFloat(searchParams.get("minPrice") as string) : undefined,
    maxPrice: searchParams.get("maxPrice") ? parseFloat(searchParams.get("maxPrice") as string) : undefined,
  });

  // Update search params when URL changes
  useEffect(() => {
    const newSearchParams = new URLSearchParams(window.location.search);
    setSearchParams(newSearchParams);
    setSearchQuery(newSearchParams.get("search") || "");
    setAppliedFilters({
      category: newSearchParams.get("category") || undefined,
      minPrice: newSearchParams.get("minPrice") ? parseFloat(newSearchParams.get("minPrice") as string) : undefined,
      maxPrice: newSearchParams.get("maxPrice") ? parseFloat(newSearchParams.get("maxPrice") as string) : undefined,
    });
  }, [location]);

  // Fetch products with filters
  const { data: products, isLoading } = useQuery({
    queryKey: [
      "/api/products",
      {
        category: appliedFilters.category,
        minPrice: appliedFilters.minPrice,
        maxPrice: appliedFilters.maxPrice,
        search: searchQuery,
      },
    ],
  });

  const handleFilterChange = (filters: {
    category?: string;
    minPrice?: number;
    maxPrice?: number;
  }) => {
    setAppliedFilters(filters);
    
    // Update URL with new filters
    const newSearchParams = new URLSearchParams();
    if (searchQuery) newSearchParams.set("search", searchQuery);
    if (filters.category) newSearchParams.set("category", filters.category);
    if (filters.minPrice !== undefined) newSearchParams.set("minPrice", filters.minPrice.toString());
    if (filters.maxPrice !== undefined) newSearchParams.set("maxPrice", filters.maxPrice.toString());
    
    window.history.pushState({}, "", `${window.location.pathname}?${newSearchParams.toString()}`);
    setSearchParams(newSearchParams);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Update URL with search query and existing filters
    const newSearchParams = new URLSearchParams(searchParams.toString());
    if (searchQuery) {
      newSearchParams.set("search", searchQuery);
    } else {
      newSearchParams.delete("search");
    }
    
    window.history.pushState({}, "", `${window.location.pathname}?${newSearchParams.toString()}`);
    setSearchParams(newSearchParams);
  };

  const clearFilter = (filter: "category" | "price" | "all") => {
    const newFilters = { ...appliedFilters };
    
    if (filter === "category" || filter === "all") {
      newFilters.category = undefined;
    }
    
    if (filter === "price" || filter === "all") {
      newFilters.minPrice = undefined;
      newFilters.maxPrice = undefined;
    }
    
    handleFilterChange(newFilters);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Eco-Friendly Products
        </h1>
        <p className="text-gray-600">
          Discover sustainable products that are good for you and the planet
        </p>
      </div>

      {/* Search Bar for Mobile (shown on all pages) */}
      <div className="mb-6 md:hidden">
        <form onSubmit={handleSearch} className="flex">
          <div className="relative w-full">
            <Input
              type="text"
              placeholder="Search eco-friendly products..."
              className="w-full pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          <Button type="submit" className="ml-2 bg-green-600 hover:bg-green-700">
            Search
          </Button>
        </form>
      </div>

      {/* Applied Filters */}
      {(appliedFilters.category || appliedFilters.minPrice || appliedFilters.maxPrice) && (
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <span className="text-sm font-medium">Applied Filters:</span>
          
          {appliedFilters.category && (
            <Badge 
              variant="secondary" 
              className="flex items-center gap-1 bg-green-50 text-green-800 hover:bg-green-100"
            >
              Category: {appliedFilters.category}
              <button 
                onClick={() => clearFilter("category")}
                className="ml-1 rounded-full hover:bg-green-200 p-0.5"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
          
          {(appliedFilters.minPrice !== undefined || appliedFilters.maxPrice !== undefined) && (
            <Badge 
              variant="secondary" 
              className="flex items-center gap-1 bg-green-50 text-green-800 hover:bg-green-100"
            >
              Price: {appliedFilters.minPrice !== undefined ? `$${appliedFilters.minPrice}` : "$0"} 
              {" - "} 
              {appliedFilters.maxPrice !== undefined ? `$${appliedFilters.maxPrice}` : "$200+"}
              <button 
                onClick={() => clearFilter("price")}
                className="ml-1 rounded-full hover:bg-green-200 p-0.5"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => clearFilter("all")}
            className="text-green-600 hover:text-green-700 hover:bg-green-50 h-7 px-2 text-xs"
          >
            Clear All
          </Button>
        </div>
      )}

      <div className="flex flex-col md:flex-row gap-6">
        {/* Filter Panel (Desktop) */}
        <div className="hidden md:block w-64 flex-shrink-0">
          <ProductFilter 
            onFilterChange={handleFilterChange}
            initialFilters={appliedFilters}
          />
        </div>

        {/* Filter Button (Mobile) */}
        <div className="md:hidden mb-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="w-full flex items-center justify-center">
                <Filter className="h-4 w-4 mr-2" /> Filter Products
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-full sm:max-w-md">
              <div className="h-full overflow-auto py-4">
                <ProductFilter 
                  onFilterChange={handleFilterChange}
                  initialFilters={appliedFilters}
                />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* Products */}
        <div className="flex-1">
          {searchQuery && (
            <div className="mb-6">
              <h2 className="text-xl font-semibold">
                Search results for "{searchQuery}"
              </h2>
              <p className="text-gray-600 text-sm">
                {products?.length || 0} products found
              </p>
            </div>
          )}
          
          <ProductGrid products={products || []} isLoading={isLoading} />
        </div>
      </div>
    </div>
  );
};

export default Buy;
