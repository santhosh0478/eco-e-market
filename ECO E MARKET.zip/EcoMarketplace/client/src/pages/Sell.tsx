import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Loader2, PackagePlus, StoreIcon } from "lucide-react";

// Define form schema for selling products
const productFormSchema = z.object({
  name: z.string().min(3, "Product name must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  price: z.coerce.number().positive("Price must be a positive number"),
  imageUrl: z.string().url("Please enter a valid image URL"),
  category: z.string().min(1, "Please select a category"),
  stock: z.coerce.number().int().positive("Stock must be a positive number"),
  ecoRating: z.coerce.number().int().min(1).max(5, "Eco rating must be between 1 and 5"),
  ecoDescription: z.string().min(10, "Eco description must be at least 10 characters"),
});

type ProductFormValues = z.infer<typeof productFormSchema>;

const Sell = () => {
  const { user, isAuthenticated } = useAuth();
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [previewImage, setPreviewImage] = useState("");

  // Redirect if not logged in
  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "You need to login to access the seller dashboard",
        variant: "destructive",
      });
      navigate("/login");
    } else if (isAuthenticated && !user?.isSeller) {
      toast({
        title: "Seller registration required",
        description: "You need to register as a seller to add products",
        variant: "destructive",
      });
    }
  }, [isAuthenticated, user, navigate, toast]);

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ["/api/products/categories"],
  });

  // Initialize form
  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      imageUrl: "",
      category: "",
      stock: 1,
      ecoRating: 3,
      ecoDescription: "",
    },
  });

  // Add product mutation
  const addProductMutation = useMutation({
    mutationFn: async (data: ProductFormValues) => {
      return await apiRequest("POST", "/api/products", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Product added",
        description: "Your product has been added successfully",
      });
      form.reset();
      setPreviewImage("");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to add product",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: ProductFormValues) => {
    addProductMutation.mutate(values);
  };

  // Handle image URL change
  const handleImageUrlChange = (url: string) => {
    setPreviewImage(url);
    form.setValue("imageUrl", url);
  };

  // List of eco-friendly image URLs
  const sampleImageUrls = [
    "https://images.unsplash.com/photo-1566707675793-3ec9e5590bb6",
    "https://images.unsplash.com/photo-1633878353810-1564c112bb5f",
    "https://images.unsplash.com/photo-1633878353733-01fb3e3bceaf",
    "https://images.unsplash.com/photo-1614270588008-6ce16de67cd9",
    "https://images.unsplash.com/photo-1563391506244-af91a410fcc9",
    "https://images.unsplash.com/photo-1591184510259-b6f1be3d7aff",
    "https://images.unsplash.com/photo-1598662972299-5408ddb8a3dc",
    "https://images.unsplash.com/photo-1624377225030-f0bb343eaa4d",
    "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688",
    "https://images.unsplash.com/photo-1513694203232-719a280e022f",
    "https://images.unsplash.com/photo-1507150615129-3ba0720f488d",
    "https://images.unsplash.com/photo-1591130901969-2a1bfafb2ee2",
  ];

  if (!isAuthenticated || !user) {
    return null; // Redirecting in useEffect
  }

  if (!user.isSeller) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-3xl">
        <Alert className="mb-6 bg-yellow-50 border-yellow-200">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            You need to register as a seller to access this feature. Please register a new account with the seller option checked.
          </AlertDescription>
        </Alert>
        
        <Button onClick={() => navigate("/register")} className="bg-green-600 hover:bg-green-700">
          Register as a Seller
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Left Column: Product Form */}
        <div className="w-full md:w-2/3">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center">
                <StoreIcon className="mr-2" /> Sell Your Eco-Friendly Products
              </CardTitle>
              <CardDescription>
                Complete the form below to list your sustainable product on EcoShop
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter product name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe your product in detail" 
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price ($)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" min="0" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="stock"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Stock Quantity</FormLabel>
                          <FormControl>
                            <Input type="number" min="1" step="1" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.map((category: string) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Image URL</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter image URL" 
                            {...field} 
                            onChange={(e) => handleImageUrlChange(e.target.value)}
                          />
                        </FormControl>
                        <FormDescription>
                          Enter a URL to an image of your product
                        </FormDescription>
                        <FormMessage />
                        <div className="mt-2 grid grid-cols-3 gap-2">
                          {sampleImageUrls.slice(0, 6).map((url, index) => (
                            <div 
                              key={index} 
                              className={`cursor-pointer border rounded-md overflow-hidden h-16 ${field.value === url ? 'ring-2 ring-green-500' : ''}`}
                              onClick={() => handleImageUrlChange(url)}
                            >
                              <img 
                                src={url} 
                                alt={`Sample ${index + 1}`} 
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ))}
                        </div>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="ecoRating"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Eco-Friendly Rating (1-5)</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select eco-rating" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1">1 - Minimal eco-friendly features</SelectItem>
                            <SelectItem value="2">2 - Some eco-friendly features</SelectItem>
                            <SelectItem value="3">3 - Moderate eco-friendly features</SelectItem>
                            <SelectItem value="4">4 - Very eco-friendly</SelectItem>
                            <SelectItem value="5">5 - Exceptional sustainability</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="ecoDescription"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sustainability Features</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe what makes this product eco-friendly" 
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={addProductMutation.isPending}
                  >
                    {addProductMutation.isPending ? (
                      <span className="flex items-center">
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Adding Product...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <PackagePlus className="mr-2 h-4 w-4" /> Add Product
                      </span>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Preview */}
        <div className="w-full md:w-1/3">
          <Card>
            <CardHeader>
              <CardTitle>Product Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-md overflow-hidden border border-gray-200 bg-gray-50 mb-4">
                {previewImage ? (
                  <img 
                    src={previewImage} 
                    alt="Product preview" 
                    className="w-full h-48 object-cover"
                  />
                ) : (
                  <div className="w-full h-48 flex items-center justify-center bg-gray-100 text-gray-400 text-sm">
                    Product image preview
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold">
                  {form.watch("name") || "Product Name"}
                </h3>
                <p className="text-sm text-gray-500 line-clamp-3">
                  {form.watch("description") || "Product description will appear here"}
                </p>
                <div className="flex justify-between items-center">
                  <span className="font-medium text-green-700">
                    ${parseFloat(form.watch("price")?.toString() || "0").toFixed(2)}
                  </span>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                    {form.watch("category") || "Category"}
                  </span>
                </div>
                <div className="flex items-center space-x-1 mt-2">
                  {[...Array(5)].map((_, i) => (
                    <svg
                      key={i}
                      className={`w-4 h-4 ${
                        i < form.watch("ecoRating")
                          ? "text-green-500 fill-green-500"
                          : "text-gray-300"
                      }`}
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                    >
                      <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                    </svg>
                  ))}
                  <span className="text-xs ml-1 text-gray-500">Eco Rating</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Tips for Eco-Friendly Products</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm space-y-2 list-disc pl-4">
                  <li>Clearly describe sustainable materials used</li>
                  <li>Mention if packaging is plastic-free or recyclable</li>
                  <li>Include certifications (e.g. organic, fair trade)</li>
                  <li>Explain how the product reduces waste</li>
                  <li>Share the product's end-of-life recyclability</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sell;
