import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import HeroSection from "@/components/home/HeroSection";
import CategorySection from "@/components/home/CategorySection";
import FeaturedProducts from "@/components/home/FeaturedProducts";
import RecommendedProducts from "@/components/product/RecommendedProducts";
import EcoImpactSection from "@/components/home/EcoImpactSection";
import { useAuth } from "@/context/AuthContext";

const Home = () => {
  // Get featured products
  const { data: featuredProducts, isLoading: isLoadingFeatured } = useQuery({
    queryKey: ["/api/products", { limit: 8 }],
  });

  // Get user recommended products if logged in
  const { user } = useAuth();
  const { data: recommendedProducts, isLoading: isLoadingRecommended } = useQuery({
    queryKey: ["/api/recommendations", { userId: user?.id, limit: 4 }],
    enabled: !!user,
  });
  
  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="flex flex-col">
      <HeroSection />
      <div className="container mx-auto px-4 py-8">
        <CategorySection />
        <FeaturedProducts 
          products={featuredProducts || []} 
          isLoading={isLoadingFeatured}
        />
        
        {user && recommendedProducts && recommendedProducts.length > 0 && (
          <RecommendedProducts 
            products={recommendedProducts} 
            isLoading={isLoadingRecommended}
            title="Recommended for You"
            description="Based on your shopping history"
          />
        )}
        
        <EcoImpactSection />
      </div>
    </div>
  );
};

export default Home;
