import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { AlertCircle, ArrowRight, ShoppingBag, ShoppingCart, Trash } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import CartItem from "@/components/cart/CartItem";

const Cart = () => {
  const { isAuthenticated } = useAuth();
  const { items, clearCart, isLoading, subtotal, totalItems } = useCart();
  const [_, navigate] = useLocation();

  useEffect(() => {
    // Redirect if not logged in
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null; // Redirecting in useEffect
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Your Cart</h1>
        <div className="animate-pulse space-y-4">
          {[...Array(3)].map((_, index) => (
            <div key={index} className="bg-gray-100 h-24 rounded-md"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Your Cart</h1>

      {items.length === 0 ? (
        <Card>
          <CardContent className="p-8 flex flex-col items-center">
            <div className="bg-gray-100 p-4 rounded-full mb-4">
              <ShoppingCart className="h-10 w-10 text-gray-400" />
            </div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">Your cart is empty</h2>
            <p className="text-gray-600 mb-6 text-center">
              Looks like you haven't added any eco-friendly products to your cart yet.
            </p>
            <Link href="/buy">
              <Button className="bg-green-600 hover:bg-green-700">
                <ShoppingBag className="h-5 w-5 mr-2" />
                Continue Shopping
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col md:flex-row gap-8">
          {/* Cart Items */}
          <div className="md:w-2/3">
            <Card>
              <CardHeader className="px-6 py-4">
                <CardTitle className="text-xl">Cart Items ({totalItems})</CardTitle>
              </CardHeader>
              <CardContent className="px-6">
                {items.map((item) => (
                  <CartItem key={item.id} item={item} />
                ))}
              </CardContent>
              <CardFooter className="px-6 py-4 flex justify-between">
                <Button
                  variant="outline"
                  className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                  onClick={() => clearCart()}
                  disabled={isLoading}
                >
                  <Trash className="h-4 w-4 mr-2" />
                  Clear Cart
                </Button>
                <Link href="/buy">
                  <Button variant="ghost">Continue Shopping</Button>
                </Link>
              </CardFooter>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="md:w-1/3">
            <Card className="sticky top-20">
              <CardHeader className="px-6 py-4">
                <CardTitle className="text-xl">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="px-6">
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-medium">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    <span className="font-medium">
                      {subtotal >= 50 ? "Free" : "$5.00"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tax</span>
                    <span className="font-medium">
                      ${(subtotal * 0.05).toFixed(2)}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span className="text-green-700">
                      ${(
                        subtotal +
                        (subtotal >= 50 ? 0 : 5) +
                        subtotal * 0.05
                      ).toFixed(2)}
                    </span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="px-6 py-4">
                <Button
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={() => navigate("/checkout")}
                >
                  Proceed to Checkout
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </CardFooter>
            </Card>

            {/* Shipping Info */}
            <div className="mt-6">
              <Card>
                <CardContent className="p-4">
                  <Alert className="bg-green-50 border-green-200">
                    <AlertCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-sm text-green-800">
                      Free shipping on orders over $50! 
                      {subtotal < 50 && ` Add $${(50 - subtotal).toFixed(2)} more to qualify.`}
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
