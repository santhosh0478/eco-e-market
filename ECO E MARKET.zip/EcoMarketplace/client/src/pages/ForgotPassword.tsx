import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, ArrowLeft, Phone, Send } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

// Define form schema for phone number
const phoneFormSchema = z.object({
  phone: z.string().min(10, "Phone number must be at least 10 characters"),
});

type PhoneFormValues = z.infer<typeof phoneFormSchema>;

const ForgotPassword = () => {
  const [location, navigate] = useLocation();
  const { requestOtp, verifyOtp, isLoading } = useAuth();
  const [otpSent, setOtpSent] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [resetSuccess, setResetSuccess] = useState(false);

  // Form for phone number
  const phoneForm = useForm<PhoneFormValues>({
    resolver: zodResolver(phoneFormSchema),
    defaultValues: {
      phone: "",
    },
  });

  // Handle phone submission
  const onPhoneSubmit = async (values: PhoneFormValues) => {
    try {
      await requestOtp(values.phone);
      setPhoneNumber(values.phone);
      setOtpSent(true);
    } catch (error) {
      // Error is handled in AuthContext
    }
  };

  // Handle OTP verification
  const onOtpVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await verifyOtp({ phone: phoneNumber, code: otp });
      setResetSuccess(true);
    } catch (error) {
      // Error is handled in AuthContext
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 flex justify-center items-center min-h-[calc(100vh-200px)]">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-start">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate("/login")}
              className="mb-2 -ml-2"
            >
              <ArrowLeft className="h-4 w-4 mr-1" /> Back to Login
            </Button>
          </div>
          <CardTitle className="text-2xl font-bold">Reset Your Password</CardTitle>
          <CardDescription>
            {!resetSuccess 
              ? "Enter your phone number to receive a verification code" 
              : "Your password has been reset successfully"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {resetSuccess ? (
            <div className="text-center space-y-4">
              <div className="rounded-full bg-green-100 p-3 mx-auto w-fit">
                <svg
                  className="w-6 h-6 text-green-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <p className="text-gray-600">
                You're now logged in. You can update your password in your profile settings.
              </p>
              <Button
                className="w-full bg-green-600 hover:bg-green-700 mt-4"
                onClick={() => navigate("/")}
              >
                Continue to Homepage
              </Button>
            </div>
          ) : !otpSent ? (
            <Form {...phoneForm}>
              <form onSubmit={phoneForm.handleSubmit(onPhoneSubmit)} className="space-y-4">
                <Alert variant="destructive" className="bg-yellow-50 text-yellow-800 border-yellow-200">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    In this demo, you'll be logged in directly after OTP verification
                  </AlertDescription>
                </Alert>
                
                <FormField
                  control={phoneForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your registered phone number" 
                          {...field} 
                          autoComplete="tel"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full bg-green-600 hover:bg-green-700"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center">
                      <span className="animate-spin mr-2">⟳</span> Sending OTP...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <Send className="h-4 w-4 mr-2" /> Send Verification Code
                    </span>
                  )}
                </Button>
              </form>
            </Form>
          ) : (
            <form onSubmit={onOtpVerifySubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="otp"
                  className="block text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Enter OTP sent to {phoneNumber}
                </label>
                <Input
                  id="otp"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  placeholder="Enter 6-digit OTP"
                  maxLength={6}
                  className="mt-1"
                />
              </div>
              <div className="flex justify-between">
                <Button 
                  type="button" 
                  variant="ghost"
                  onClick={() => setOtpSent(false)}
                  className="text-sm text-green-600 hover:text-green-700"
                >
                  Change number
                </Button>
                <Button 
                  type="button" 
                  variant="ghost"
                  disabled={isLoading}
                  onClick={() => onPhoneSubmit({ phone: phoneNumber })}
                  className="text-sm text-green-600 hover:text-green-700"
                >
                  Resend OTP
                </Button>
              </div>
              <Button 
                type="submit" 
                className="w-full bg-green-600 hover:bg-green-700"
                disabled={isLoading || otp.length !== 6}
              >
                {isLoading ? (
                  <span className="flex items-center">
                    <span className="animate-spin mr-2">⟳</span> Verifying...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <Phone className="h-4 w-4 mr-2" /> Verify & Continue
                  </span>
                )}
              </Button>
            </form>
          )}
        </CardContent>
        <CardFooter className="flex flex-col">
          <div className="text-center mt-2">
            <p className="text-sm text-gray-600">
              Remember your password?{" "}
              <Link href="/login" className="text-green-600 hover:text-green-700 font-medium">
                Sign in
              </Link>
            </p>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default ForgotPassword;
