import { useEffect } from "react";
import { Link, useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ArrowLeft,
  CheckCircle,
  CircleDashed,
  Truck,
  Package,
  Clock,
  Home,
} from "lucide-react";
import { Separator } from "@/components/ui/separator";

const OrderTracking = () => {
  const [match, params] = useRoute("/order-tracking/:id");
  const [_, navigate] = useLocation();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    // Redirect if not logged in
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  // Fetch order details
  const { data: order, isLoading } = useQuery({
    queryKey: [`/api/orders/${params?.id}`],
    enabled: !!params?.id && isAuthenticated,
  });

  if (!match || !isAuthenticated) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-green-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Order Not Found</h2>
        <p className="mb-8">The order you're looking for doesn't exist or you don't have permission to view it.</p>
        <Link href="/">
          <Button className="bg-green-600 hover:bg-green-700">
            Return to Homepage
          </Button>
        </Link>
      </div>
    );
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  // Calculate delivery estimate (5 days from order date)
  const orderDate = new Date(order.createdAt);
  const estimatedDelivery = new Date(orderDate);
  estimatedDelivery.setDate(orderDate.getDate() + 5);

  // Order progress steps
  const steps = [
    { 
      label: "Order Placed", 
      description: `${formatDate(order.createdAt)}`,
      icon: <CheckCircle className="h-6 w-6" />,
      status: "completed"
    },
    { 
      label: "Processing", 
      description: "Your order is being processed",
      icon: order.status === "pending" ? <CircleDashed className="h-6 w-6" /> : <CheckCircle className="h-6 w-6" />,
      status: order.status === "pending" ? "current" : "completed"
    },
    { 
      label: "Shipped", 
      description: order.status === "shipped" || order.status === "delivered" ? 
        "Your order has been shipped" : 
        "Your order will be shipped soon",
      icon: order.status === "shipped" || order.status === "delivered" ? 
        <CheckCircle className="h-6 w-6" /> : <Package className="h-6 w-6" />,
      status: order.status === "shipped" || order.status === "delivered" ? "completed" : "upcoming"
    },
    { 
      label: "Delivered", 
      description: order.status === "delivered" ? 
        "Your order has been delivered" : 
        `Estimated delivery: ${formatDate(estimatedDelivery.toISOString())}`,
      icon: order.status === "delivered" ? <CheckCircle className="h-6 w-6" /> : <Truck className="h-6 w-6" />,
      status: order.status === "delivered" ? "completed" : "upcoming"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-6">
        <Button
          variant="ghost"
          className="mb-4"
          onClick={() => navigate(`/order-confirmation/${params?.id}`)}
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Order Confirmation
        </Button>
        
        <h1 className="text-3xl font-bold text-gray-900">Track Your Order</h1>
        <p className="text-gray-600">Order #{order.id} • Placed on {formatDate(order.createdAt)}</p>
      </div>

      <Card className="mb-8">
        <CardHeader className="bg-green-50 border-b border-green-100">
          <CardTitle className="text-xl">Shipping Status</CardTitle>
          <CardDescription>
            Current status: <span className="font-medium capitalize">{order.status}</span>
          </CardDescription>
        </CardHeader>
        <CardContent className="py-6">
          {/* Progress Tracker */}
          <div className="relative">
            {/* Progress Line */}
            <div className="absolute left-[27px] top-0 bottom-0 w-0.5 bg-gray-200 z-0"></div>
            
            {/* Steps */}
            <div className="relative z-10 space-y-8">
              {steps.map((step, index) => (
                <div key={index} className="flex items-start">
                  <div className={`rounded-full flex items-center justify-center w-14 h-14 flex-shrink-0 
                    ${step.status === 'completed' ? 'bg-green-100 text-green-600' : 
                      step.status === 'current' ? 'bg-blue-100 text-blue-600' : 
                      'bg-gray-100 text-gray-400'}`}
                  >
                    {step.icon}
                  </div>
                  <div className="ml-4 pt-3">
                    <h3 className={`font-medium ${
                      step.status === 'completed' ? 'text-green-700' : 
                      step.status === 'current' ? 'text-blue-700' : 
                      'text-gray-500'
                    }`}>{step.label}</h3>
                    <p className="text-sm text-gray-600 mt-1">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Order Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Shipping Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Shipping Information</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 whitespace-pre-line">
              {order.shippingAddress}
            </p>
          </CardContent>
        </Card>

        {/* Order Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Order Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-sm">
                <span className="font-medium">{order.items.length}</span> item{order.items.length !== 1 ? 's' : ''}
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Payment Method:</span>
                <span className="font-medium capitalize">
                  {order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total:</span>
                <span className="font-medium text-green-700">${order.totalAmount.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Order Items */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Order Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {order.items.map((item: any) => (
              <div key={item.id} className="flex items-start py-2 border-b border-gray-100 last:border-0">
                <div className="w-16 h-16 rounded-md overflow-hidden flex-shrink-0 bg-gray-100">
                  <img
                    src={item.product.imageUrl}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="ml-4 flex-1">
                  <h4 className="font-medium">{item.product.name}</h4>
                  <div className="text-sm text-gray-600 flex items-center justify-between mt-1">
                    <span>Qty: {item.quantity}</span>
                    <span className="font-medium text-gray-900">
                      ${(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
        <CardFooter className="border-t pt-4 flex justify-between">
          <Button variant="outline" onClick={() => navigate("/")}>
            <Home className="mr-2 h-4 w-4" /> Continue Shopping
          </Button>
          <Link href={`/order-confirmation/${order.id}`}>
            <Button variant="ghost">
              View Order Details
            </Button>
          </Link>
        </CardFooter>
      </Card>

      {/* Eco-friendly delivery information */}
      <div className="mt-8">
        <Card className="bg-green-50 border-green-100">
          <CardContent className="p-6">
            <div className="flex justify-center mb-3">
              <Truck className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-center font-semibold text-green-800 mb-2">Eco-Friendly Delivery</h3>
            <p className="text-center text-green-700 text-sm">
              We use carbon-neutral shipping and eco-friendly packaging materials for all orders. 
              Thank you for supporting sustainable practices!
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OrderTracking;
