import { useEffect } from "react";
import { Link, useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  CheckCircle,
  Home,
  Box,
  ArrowRight,
  Truck,
  ShoppingBag,
  Clock,
} from "lucide-react";
import { Separator } from "@/components/ui/separator";

const OrderConfirmation = () => {
  const [match, params] = useRoute("/order-confirmation/:id");
  const [_, navigate] = useLocation();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    // Redirect if not logged in
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  // Fetch order details
  const { data: order, isLoading } = useQuery({
    queryKey: [`/api/orders/${params?.id}`],
    enabled: !!params?.id && isAuthenticated,
  });

  if (!match || !isAuthenticated) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-green-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Order Not Found</h2>
        <p className="mb-8">The order you're looking for doesn't exist or you don't have permission to view it.</p>
        <Link href="/">
          <Button className="bg-green-600 hover:bg-green-700">
            Return to Homepage
          </Button>
        </Link>
      </div>
    );
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const estimatedDelivery = new Date();
  estimatedDelivery.setDate(estimatedDelivery.getDate() + 5);

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <Card className="border-green-100">
        <CardHeader className="text-center border-b border-green-100 bg-green-50 text-green-800">
          <div className="flex justify-center mb-4">
            <div className="bg-white rounded-full p-3 border border-green-200">
              <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
          </div>
          <CardTitle className="text-2xl mb-1">Order Confirmed!</CardTitle>
          <CardDescription className="text-green-700">
            Your order #{order.id} has been placed successfully
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="text-center">
              <div className="bg-green-50 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2">
                <Clock className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-medium mb-1">Order Date</h3>
              <p className="text-gray-600 text-sm">{formatDate(order.createdAt)}</p>
            </div>
            <div className="text-center">
              <div className="bg-green-50 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2">
                <Box className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-medium mb-1">Order Status</h3>
              <p className="text-gray-600 text-sm capitalize">{order.status}</p>
            </div>
            <div className="text-center">
              <div className="bg-green-50 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2">
                <Truck className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-medium mb-1">Estimated Delivery</h3>
              <p className="text-gray-600 text-sm">{formatDate(estimatedDelivery.toISOString())}</p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Order Items */}
            <div>
              <h3 className="font-semibold text-lg mb-4">Order Items</h3>
              <Card>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    {order.items.map((item: any) => (
                      <div key={item.id} className="flex items-start py-2">
                        <div className="w-16 h-16 rounded-md overflow-hidden flex-shrink-0 bg-gray-100">
                          <img
                            src={item.product.imageUrl}
                            alt={item.product.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="ml-4 flex-1">
                          <h4 className="font-medium">{item.product.name}</h4>
                          <div className="text-sm text-gray-600 flex items-center justify-between mt-1">
                            <span>Qty: {item.quantity}</span>
                            <span className="font-medium text-gray-900">
                              ${(item.price * item.quantity).toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Shipping & Payment */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-lg mb-4">Shipping Address</h3>
                <Card>
                  <CardContent className="p-4">
                    <p className="whitespace-pre-line text-gray-700">
                      {order.shippingAddress}
                    </p>
                  </CardContent>
                </Card>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-4">Payment Method</h3>
                <Card>
                  <CardContent className="p-4">
                    <p className="text-gray-700 capitalize">
                      {order.paymentMethod === "cod" 
                        ? "Cash on Delivery" 
                        : order.paymentMethod}
                    </p>
                    <div className="flex justify-between items-center mt-4">
                      <span className="text-gray-600">Total Amount:</span>
                      <span className="font-semibold text-lg text-green-700">
                        ${order.totalAmount.toFixed(2)}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row justify-center gap-4 border-t pt-6">
          <Link href="/">
            <Button variant="outline" className="w-full sm:w-auto">
              <Home className="mr-2 h-4 w-4" /> Return to Home
            </Button>
          </Link>
          <Link href={`/order-tracking/${order.id}`}>
            <Button className="bg-green-600 hover:bg-green-700 w-full sm:w-auto">
              Track Order <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardFooter>
      </Card>

      {/* Environmental Impact */}
      <div className="mt-8">
        <Card className="bg-green-50 border-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-center mb-4">
              <div className="bg-white rounded-full p-2 border border-green-200">
                <Truck className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <h3 className="text-center font-semibold text-green-800 mb-2">Environmental Impact of Your Purchase</h3>
            <p className="text-center text-green-700 text-sm">
              By purchasing eco-friendly products, you've helped reduce plastic waste and carbon emissions. Thank you for making a sustainable choice!
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OrderConfirmation;
