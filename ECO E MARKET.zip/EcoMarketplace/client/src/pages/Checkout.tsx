import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, 
  CheckCircle2, 
  ShoppingBag,
  Loader2,
  AlertCircle,
  XCircle
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import ShippingForm from "@/components/checkout/ShippingForm";
import PaymentMethodSelector from "@/components/checkout/PaymentMethodSelector";

const Checkout = () => {
  const { isAuthenticated, user } = useAuth();
  const { items, clearCart, subtotal, totalItems } = useCart();
  const [location, navigate] = useLocation();
  const { toast } = useToast();

  const [currentStep, setCurrentStep] = useState("shipping");
  const [shippingInfo, setShippingInfo] = useState<any>(null);
  const [paymentMethod, setPaymentMethod] = useState("cod");

  useEffect(() => {
    // Redirect if not logged in or cart is empty
    if (!isAuthenticated) {
      navigate("/login");
    } else if (items.length === 0) {
      navigate("/cart");
    }
  }, [isAuthenticated, items, navigate]);

  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await apiRequest("POST", "/api/orders", orderData);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Order placed successfully",
        description: "Your order has been placed and is being processed.",
      });
      navigate(`/order-confirmation/${data.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to place order",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleShippingSubmit = (values: any) => {
    setShippingInfo(values);
    setCurrentStep("payment");
  };

  const handlePaymentMethodChange = (method: string) => {
    setPaymentMethod(method);
  };

  const handlePlaceOrder = () => {
    if (!shippingInfo) {
      toast({
        title: "Shipping information required",
        description: "Please provide your shipping details.",
        variant: "destructive",
      });
      setCurrentStep("shipping");
      return;
    }

    // Format shipping address
    const shippingAddress = `${shippingInfo.fullName}, ${shippingInfo.phone}, ${shippingInfo.addressLine1}, ${
      shippingInfo.addressLine2 ? shippingInfo.addressLine2 + ", " : ""
    }${shippingInfo.city}, ${shippingInfo.state} ${shippingInfo.zipCode}`;

    // Calculate total amount
    const shippingCost = subtotal >= 50 ? 0 : 5;
    const tax = subtotal * 0.05;
    const totalAmount = subtotal + shippingCost + tax;

    const orderData = {
      totalAmount,
      paymentMethod,
      shippingAddress,
    };

    createOrderMutation.mutate(orderData);
  };

  if (!isAuthenticated || items.length === 0) {
    return null; // Redirecting in useEffect
  }

  const isPlacingOrder = createOrderMutation.isPending;

  return (
    <div className="container mx-auto px-4 py-8">
      <Button
        variant="ghost"
        className="mb-6"
        onClick={() => navigate("/cart")}
      >
        <ArrowLeft className="h-4 w-4 mr-2" /> Back to Cart
      </Button>

      <h1 className="text-3xl font-bold text-gray-900 mb-8">Checkout</h1>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Checkout Steps */}
        <div className="md:w-2/3">
          <Tabs defaultValue={currentStep} value={currentStep} onValueChange={setCurrentStep}>
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="shipping" disabled={isPlacingOrder}>
                1. Shipping
              </TabsTrigger>
              <TabsTrigger 
                value="payment" 
                disabled={!shippingInfo || isPlacingOrder}
              >
                2. Payment
              </TabsTrigger>
            </TabsList>

            <TabsContent value="shipping">
              <Card>
                <CardContent className="p-6">
                  <ShippingForm
                    onSubmit={handleShippingSubmit}
                    defaultValues={{
                      fullName: user?.fullName || "",
                      phone: user?.phone || "",
                      addressLine1: user?.address || "",
                      city: user?.city || "",
                      state: user?.state || "",
                      zipCode: user?.zipCode || "",
                    }}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payment">
              <Card>
                <CardContent className="p-6">
                  <PaymentMethodSelector 
                    onPaymentMethodSelect={(method, details) => {
                      setPaymentMethod(method);
                      toast({
                        title: `${method} selected`,
                        description: details ? 
                          `Payment details saved successfully` : 
                          `Your order will be processed with ${method}`,
                      });
                    }} 
                  />

                  <div className="mt-8">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <Button
                        variant="outline"
                        className="w-full text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                        onClick={() => {
                          navigate("/cart");
                          toast({
                            title: "Order cancelled",
                            description: "You can continue shopping from your cart.",
                          });
                        }}
                        disabled={isPlacingOrder}
                      >
                        <XCircle className="mr-2 h-4 w-4" /> Cancel Order
                      </Button>
                      
                      <Button
                        className="w-full bg-green-600 hover:bg-green-700"
                        onClick={handlePlaceOrder}
                        disabled={isPlacingOrder}
                      >
                        {isPlacingOrder ? (
                          <span className="flex items-center">
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                          </span>
                        ) : (
                          <span className="flex items-center">
                            <CheckCircle2 className="mr-2 h-4 w-4" /> Place Order
                          </span>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Order Summary */}
        <div className="md:w-1/3">
          <Card className="sticky top-20">
            <CardHeader className="px-6 py-4">
              <CardTitle className="text-xl">Order Summary</CardTitle>
              <CardDescription>
                {totalItems} item{totalItems !== 1 ? "s" : ""}
              </CardDescription>
            </CardHeader>
            <CardContent className="px-6">
              <div className="space-y-4">
                {/* Product list summary */}
                <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                  {items.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <div className="flex items-start">
                        <span className="text-gray-500 mr-1">{item.quantity} ×</span>
                        <span className="line-clamp-1">{item.product.name}</span>
                      </div>
                      <span className="font-medium">
                        ${(item.quantity * item.product.price).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>

                <Separator />

                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-medium">
                    {subtotal >= 50 ? "Free" : "$5.00"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax</span>
                  <span className="font-medium">
                    ${(subtotal * 0.05).toFixed(2)}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-green-700">
                    ${(
                      subtotal +
                      (subtotal >= 50 ? 0 : 5) +
                      subtotal * 0.05
                    ).toFixed(2)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
