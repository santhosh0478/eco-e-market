import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { LogIn, Mail, Phone, Lock, User } from "lucide-react";

// Define form schema for login
const loginFormSchema = z.object({
  identifier: z.string().min(1, "Username, email, or phone is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// Define form schema for OTP login
const otpFormSchema = z.object({
  phone: z.string().min(10, "Phone number must be at least 10 characters"),
});

type LoginFormValues = z.infer<typeof loginFormSchema>;
type OtpFormValues = z.infer<typeof otpFormSchema>;

const Login = () => {
  const [location, navigate] = useLocation();
  const { login, requestOtp, verifyOtp, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("credentials");
  const [otpSent, setOtpSent] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");

  // Form for credentials login
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: {
      identifier: "",
      password: "",
    },
  });

  // Form for OTP request
  const otpForm = useForm<OtpFormValues>({
    resolver: zodResolver(otpFormSchema),
    defaultValues: {
      phone: "",
    },
  });

  // Handle credentials login
  const onLoginSubmit = async (values: LoginFormValues) => {
    try {
      // Determine if identifier is username, email, or phone
      const isEmail = values.identifier.includes('@');
      const isPhone = /^\d+$/.test(values.identifier);
      
      const loginData = {
        password: values.password,
        ...(isEmail ? { email: values.identifier } :
           isPhone ? { phone: values.identifier } :
                     { username: values.identifier })
      };

      await login(loginData);
      navigate("/");
    } catch (error) {
      // Error is handled in AuthContext
    }
  };

  // Handle OTP request
  const onOtpRequestSubmit = async (values: OtpFormValues) => {
    try {
      await requestOtp(values.phone);
      setPhoneNumber(values.phone);
      setOtpSent(true);
    } catch (error) {
      // Error is handled in AuthContext
    }
  };

  // Handle OTP verification
  const onOtpVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await verifyOtp({ phone: phoneNumber, code: otp });
      navigate("/");
    } catch (error) {
      // Error is handled in AuthContext
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 flex justify-center items-center min-h-[calc(100vh-200px)]">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-2xl font-bold">Welcome back</CardTitle>
          <CardDescription>
            Sign in to your account to continue
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="credentials" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 w-full mb-6">
              <TabsTrigger value="credentials">
                <User className="h-4 w-4 mr-2" /> Credentials
              </TabsTrigger>
              <TabsTrigger value="phone">
                <Phone className="h-4 w-4 mr-2" /> Phone
              </TabsTrigger>
            </TabsList>

            <TabsContent value="credentials">
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="identifier"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username, Email, or Phone</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter your username, email, or phone" 
                            {...field}
                            autoComplete="username"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="Enter your password" 
                            {...field}
                            autoComplete="current-password"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="text-right">
                    <Link href="/forgot-password" className="text-sm text-green-600 hover:text-green-700">
                      Forgot password?
                    </Link>
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <span className="flex items-center">
                        <span className="animate-spin mr-2">⟳</span> Signing in...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <LogIn className="h-4 w-4 mr-2" /> Sign In
                      </span>
                    )}
                  </Button>
                </form>
              </Form>
            </TabsContent>

            <TabsContent value="phone">
              {!otpSent ? (
                <Form {...otpForm}>
                  <form onSubmit={otpForm.handleSubmit(onOtpRequestSubmit)} className="space-y-4">
                    <FormField
                      control={otpForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter your phone number" 
                              {...field} 
                              autoComplete="tel"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      className="w-full bg-green-600 hover:bg-green-700"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <span className="flex items-center">
                          <span className="animate-spin mr-2">⟳</span> Sending OTP...
                        </span>
                      ) : (
                        <span className="flex items-center">
                          <Phone className="h-4 w-4 mr-2" /> Send OTP
                        </span>
                      )}
                    </Button>
                  </form>
                </Form>
              ) : (
                <form onSubmit={onOtpVerifySubmit} className="space-y-4">
                  <div>
                    <label
                      htmlFor="otp"
                      className="block text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Enter OTP sent to {phoneNumber}
                    </label>
                    <Input
                      id="otp"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      placeholder="Enter 6-digit OTP"
                      maxLength={6}
                      className="mt-1"
                    />
                  </div>
                  <div className="flex justify-between">
                    <Button 
                      type="button" 
                      variant="ghost"
                      onClick={() => setOtpSent(false)}
                      className="text-sm text-green-600 hover:text-green-700"
                    >
                      Change number
                    </Button>
                    <Button 
                      type="button" 
                      variant="ghost"
                      disabled={isLoading}
                      onClick={() => onOtpRequestSubmit({ phone: phoneNumber })}
                      className="text-sm text-green-600 hover:text-green-700"
                    >
                      Resend OTP
                    </Button>
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={isLoading || otp.length !== 6}
                  >
                    {isLoading ? (
                      <span className="flex items-center">
                        <span className="animate-spin mr-2">⟳</span> Verifying...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <LogIn className="h-4 w-4 mr-2" /> Verify & Login
                      </span>
                    )}
                  </Button>
                </form>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col">
          <div className="text-center mt-2">
            <p className="text-sm text-gray-600">
              Don't have an account?{" "}
              <Link href="/register" className="text-green-600 hover:text-green-700 font-medium">
                Sign up
              </Link>
            </p>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Login;
