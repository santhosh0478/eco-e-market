import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import {
  ShoppingCart,
  Star,
  Check,
  Truck,
  Leaf,
  Package,
  Recycle,
  Minus,
  Plus,
  Heart,
  Globe,
  ShoppingBag,
} from "lucide-react";
import RecommendedProducts from "@/components/product/RecommendedProducts";

const ProductDetail = () => {
  const [match, params] = useRoute("/products/:id");
  const [_, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const { addToCart, isLoading: isCartLoading } = useCart();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Record product view for AI recommendations if user is authenticated
    if (isAuthenticated && params?.id) {
      const productId = parseInt(params.id);
      fetch(`/api/products?productId=${productId}`);
    }
  }, [params?.id, isAuthenticated]);

  // Fetch product details
  const { data: product, isLoading } = useQuery({
    queryKey: [`/api/products/${params?.id}`],
    enabled: !!params?.id,
  });

  // Fetch product reviews
  const { data: reviews, isLoading: isLoadingReviews } = useQuery({
    queryKey: [`/api/products/${params?.id}/reviews`],
    enabled: !!params?.id,
  });

  // Fetch similar products based on current product
  const { data: similarProducts, isLoading: isLoadingSimilar } = useQuery({
    queryKey: [`/api/products/${params?.id}/similar`],
    enabled: !!params?.id,
  });
  
  // Fetch personalized recommendations for the user
  const { data: recommendedProducts, isLoading: isLoadingRecommended } = useQuery({
    queryKey: ["/api/recommendations"],
    enabled: isAuthenticated && !!params?.id,
  });

  if (!match) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/2 aspect-square bg-gray-200 rounded-md"></div>
            <div className="md:w-1/2 space-y-4">
              <div className="h-6 bg-gray-200 rounded w-3/4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              <div className="h-4 bg-gray-200 rounded w-full"></div>
              <div className="h-4 bg-gray-200 rounded w-full"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-10 bg-gray-200 rounded w-1/2 mt-8"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <p className="mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate("/buy")} className="bg-green-600 hover:bg-green-700">
          Continue Shopping
        </Button>
      </div>
    );
  }

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 1) return;
    if (value > product.stock) return;
    setQuantity(value);
  };

  const handleIncrement = () => {
    if (quantity < product.stock) {
      setQuantity(quantity + 1);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to add items to your cart",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }

    addToCart(product.id, quantity);
  };

  const handleBuyNow = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to purchase items",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }

    // Add to cart first and then navigate to checkout
    addToCart(product.id, quantity).then(() => {
      navigate("/checkout");
    });
  };

  // Generate eco rating stars
  const renderEcoRating = () => {
    const stars = [];
    for (let i = 0; i < 5; i++) {
      stars.push(
        <Star
          key={i}
          size={18}
          className={`${
            i < product.ecoRating ? "text-green-500 fill-green-500" : "text-gray-300"
          }`}
        />
      );
    }
    return stars;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Product Image */}
        <div className="md:w-1/2">
          <div className="aspect-square overflow-hidden rounded-lg border border-gray-200 bg-gray-50">
            <img
              src={product.imageUrl}
              alt={product.name}
              className="h-full w-full object-cover"
            />
          </div>
        </div>

        {/* Product Details */}
        <div className="md:w-1/2">
          <Badge variant="outline" className="mb-4 bg-green-50 text-green-800 border-green-200">
            {product.category}
          </Badge>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
          
          <div className="flex items-center space-x-1 mb-4">
            {renderEcoRating()}
            <span className="ml-2 text-sm text-gray-600">Eco Rating</span>
          </div>
          
          <div className="text-2xl font-bold text-green-700 mb-4">
            ${product.price.toFixed(2)}
          </div>

          <p className="text-gray-700 mb-6">{product.description}</p>

          {/* Eco Information */}
          <Card className="mb-6 bg-green-50 border-green-100">
            <CardHeader className="py-3 px-4">
              <CardTitle className="text-sm font-medium flex items-center text-green-800">
                <Leaf className="h-4 w-4 mr-2" /> Sustainability Information
              </CardTitle>
            </CardHeader>
            <CardContent className="py-3 px-4 text-sm text-green-800">
              <p>{product.ecoDescription}</p>
            </CardContent>
          </Card>

          {/* Stock and Quantity */}
          <div className="mb-6">
            <div className="flex items-center mb-4">
              <Check className={`h-5 w-5 ${product.stock > 0 ? 'text-green-500' : 'text-red-500'} mr-2`} />
              <span className={`font-medium ${product.stock > 0 ? 'text-green-700' : 'text-red-600'}`}>
                {product.stock > 0 ? `In Stock (${product.stock} available)` : 'Out of Stock'}
              </span>
            </div>

            {product.stock > 0 && (
              <div className="flex items-center">
                <span className="mr-3 text-gray-700">Quantity:</span>
                <div className="flex items-center border rounded overflow-hidden">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 rounded-none"
                    onClick={handleDecrement}
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-3 w-3" />
                  </Button>
                  <Input
                    type="number"
                    min="1"
                    max={product.stock}
                    value={quantity}
                    onChange={handleQuantityChange}
                    className="w-12 h-8 text-center p-0 border-0"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 rounded-none"
                    onClick={handleIncrement}
                    disabled={quantity >= product.stock}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 mb-6">
            <Button
              onClick={handleAddToCart}
              className="flex-1 bg-green-100 text-green-800 hover:bg-green-200 border border-green-200"
              disabled={isCartLoading || product.stock <= 0}
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              Add to Cart
            </Button>
            <Button
              onClick={handleBuyNow}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
              disabled={isCartLoading || product.stock <= 0}
            >
              <ShoppingBag className="h-5 w-5 mr-2" />
              Buy Now
            </Button>
          </div>

          {/* Shipping & Returns */}
          <div className="space-y-3 text-sm">
            <div className="flex items-start">
              <Truck className="h-5 w-5 mr-3 text-gray-600 mt-0.5" />
              <div>
                <span className="font-medium text-gray-900 block">Free Shipping</span>
                <span className="text-gray-600">For orders over $50</span>
              </div>
            </div>
            <div className="flex items-start">
              <Package className="h-5 w-5 mr-3 text-gray-600 mt-0.5" />
              <div>
                <span className="font-medium text-gray-900 block">Eco-Friendly Packaging</span>
                <span className="text-gray-600">Sustainable, minimal packaging</span>
              </div>
            </div>
            <div className="flex items-start">
              <Recycle className="h-5 w-5 mr-3 text-gray-600 mt-0.5" />
              <div>
                <span className="font-medium text-gray-900 block">30-Day Returns</span>
                <span className="text-gray-600">Hassle-free return policy</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Separator className="my-12" />

      {/* Environmental Impact */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Environmental Impact</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="mb-4 bg-green-50 p-3 rounded-full w-fit">
                <Globe className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Carbon Footprint</h3>
              <p className="text-gray-600 text-sm">
                Using this product helps reduce carbon emissions compared to conventional alternatives.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="mb-4 bg-green-50 p-3 rounded-full w-fit">
                <Recycle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Recyclability</h3>
              <p className="text-gray-600 text-sm">
                Made from materials that are recyclable or biodegradable at end of life.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="mb-4 bg-green-50 p-3 rounded-full w-fit">
                <Leaf className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Sustainable Materials</h3>
              <p className="text-gray-600 text-sm">
                Produced using sustainably sourced or recycled materials that minimize environmental impact.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Customer Reviews</h2>
        
        {isLoadingReviews ? (
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, index) => (
              <div key={index} className="bg-gray-100 p-4 rounded-md">
                <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/3 mb-4"></div>
                <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        ) : reviews && reviews.length > 0 ? (
          <div className="space-y-4">
            {reviews.map((review: any) => (
              <Card key={review.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium">{review.user?.username || "Anonymous"}</div>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={16}
                          className={`${
                            i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 mb-2">
                    {new Date(review.createdAt).toLocaleDateString()}
                  </div>
                  <p className="text-gray-700">{review.comment}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-gray-600">No reviews yet. Be the first to leave a review!</p>
            </CardContent>
          </Card>
        )}
      </section>

      {/* Similar Products based on this product */}
      {similarProducts && similarProducts.length > 0 && (
        <RecommendedProducts 
          products={similarProducts} 
          isLoading={isLoadingSimilar}
          title="Similar Eco-Friendly Products"
          description="You might also like these similar sustainable products based on what you're viewing."
        />
      )}
      
      {/* Personalized Recommendations based on browsing history */}
      {isAuthenticated && recommendedProducts && recommendedProducts.length > 0 && (
        <RecommendedProducts 
          products={recommendedProducts} 
          isLoading={isLoadingRecommended}
          title="Just For You"
          description="Personalized recommendations based on your interests and browsing history."
        />
      )}
    </div>
  );
};

export default ProductDetail;
