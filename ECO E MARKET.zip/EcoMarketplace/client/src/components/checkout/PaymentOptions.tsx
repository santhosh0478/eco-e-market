import { useState } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { FaCreditCard, FaGooglePay, FaApplePay } from "react-icons/fa";
import { SiPhonepe, SiPaytm } from "react-icons/si";

interface PaymentOptionsProps {
  onPaymentMethodChange: (method: string) => void;
}

const PaymentOptions = ({ onPaymentMethodChange }: PaymentOptionsProps) => {
  const [paymentMethod, setPaymentMethod] = useState("cod");
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");

  const handlePaymentMethodChange = (value: string) => {
    setPaymentMethod(value);
    onPaymentMethodChange(value);
  };

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold">Payment Method</h3>
      <RadioGroup
        value={paymentMethod}
        onValueChange={handlePaymentMethodChange}
        className="space-y-3"
      >
        {/* UPI Options */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-gray-500">UPI / Wallets</h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Card className={`border cursor-pointer ${paymentMethod === "phonepe" ? "border-green-500 bg-green-50" : ""}`}>
              <CardContent className="p-3 flex items-center">
                <RadioGroupItem value="phonepe" id="phonepe" className="mr-2" />
                <Label htmlFor="phonepe" className="flex items-center cursor-pointer">
                  <SiPhonepe className="h-5 w-5 mr-2 text-purple-600" />
                  <span>PhonePe</span>
                </Label>
              </CardContent>
            </Card>

            <Card className={`border cursor-pointer ${paymentMethod === "googlepay" ? "border-green-500 bg-green-50" : ""}`}>
              <CardContent className="p-3 flex items-center">
                <RadioGroupItem value="googlepay" id="googlepay" className="mr-2" />
                <Label htmlFor="googlepay" className="flex items-center cursor-pointer">
                  <FaGooglePay className="h-5 w-5 mr-2 text-blue-500" />
                  <span>Google Pay</span>
                </Label>
              </CardContent>
            </Card>

            <Card className={`border cursor-pointer ${paymentMethod === "paytm" ? "border-green-500 bg-green-50" : ""}`}>
              <CardContent className="p-3 flex items-center">
                <RadioGroupItem value="paytm" id="paytm" className="mr-2" />
                <Label htmlFor="paytm" className="flex items-center cursor-pointer">
                  <SiPaytm className="h-5 w-5 mr-2 text-blue-600" />
                  <span>Paytm</span>
                </Label>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Card Payment */}
        <div className="pt-3">
          <Card className={`border cursor-pointer ${paymentMethod === "card" ? "border-green-500 bg-green-50" : ""}`}>
            <CardContent className="p-4">
              <div className="flex items-center mb-4">
                <RadioGroupItem value="card" id="card" className="mr-2" />
                <Label htmlFor="card" className="flex items-center cursor-pointer">
                  <FaCreditCard className="h-5 w-5 mr-2 text-gray-700" />
                  <span>Credit / Debit Card</span>
                </Label>
              </div>

              {paymentMethod === "card" && (
                <div className="space-y-3 mt-2 pl-6">
                  <div>
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="cardName">Name on Card</Label>
                    <Input
                      id="cardName"
                      placeholder="John Doe"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="expiryDate">Expiry Date (MM/YY)</Label>
                      <Input
                        id="expiryDate"
                        placeholder="MM/YY"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV</Label>
                      <Input
                        id="cvv"
                        type="password"
                        placeholder="123"
                        maxLength={3}
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Cash on Delivery */}
        <Card className={`border cursor-pointer ${paymentMethod === "cod" ? "border-green-500 bg-green-50" : ""}`}>
          <CardContent className="p-3 flex items-center">
            <RadioGroupItem value="cod" id="cod" className="mr-2" />
            <Label htmlFor="cod" className="cursor-pointer">
              Cash on Delivery
            </Label>
          </CardContent>
        </Card>
      </RadioGroup>
    </div>
  );
};

export default PaymentOptions;
