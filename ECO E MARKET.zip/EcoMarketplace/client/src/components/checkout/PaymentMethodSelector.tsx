import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  CreditCard, 
  Smartphone, 
  Check, 
  AlertCircle
} from "lucide-react";
import { FaGooglePay, FaCcVisa, FaCcMastercard, FaCcAmex } from "react-icons/fa";
import { SiPaytm, SiPhonepe } from "react-icons/si";

interface PaymentMethodSelectorProps {
  onPaymentMethodSelect: (method: string, details?: any) => void;
}

const PaymentMethodSelector = ({ onPaymentMethodSelect }: PaymentMethodSelectorProps) => {
  const [paymentMethod, setPaymentMethod] = useState<string>("creditCard");
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvc, setCardCvc] = useState("");
  const [upiId, setUpiId] = useState("");
  const [showDetails, setShowDetails] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState("");

  const handlePaymentMethodChange = (value: string) => {
    setPaymentMethod(value);
    setShowDetails(true);
    setError("");
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "");
    setCardNumber(value.replace(/(.{4})/g, "$1 ").trim().substring(0, 19));
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "");
    if (value.length <= 2) {
      setCardExpiry(value);
    } else {
      setCardExpiry(value.substring(0, 2) + "/" + value.substring(2, 4));
    }
  };

  const validateAndProceed = () => {
    setError("");
    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);

      if (paymentMethod === "creditCard") {
        if (cardNumber.length < 16 || !cardName || cardExpiry.length < 5 || cardCvc.length < 3) {
          setError("Please fill all card details correctly");
          return;
        }
        onPaymentMethodSelect("Credit/Debit Card", { 
          cardNumber, 
          cardName, 
          cardExpiry, 
          lastFourDigits: cardNumber.replace(/\s/g, "").slice(-4) 
        });
      } else if (["phonepe", "googlepay", "paytm"].includes(paymentMethod)) {
        if (!upiId || !upiId.includes("@")) {
          setError("Please enter a valid UPI ID");
          return;
        }
        onPaymentMethodSelect(
          paymentMethod === "phonepe" ? "PhonePe" : 
          paymentMethod === "googlepay" ? "Google Pay" : "Paytm", 
          { upiId }
        );
      } else {
        onPaymentMethodSelect("Cash on Delivery");
      }
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <RadioGroup
        value={paymentMethod}
        onValueChange={handlePaymentMethodChange}
        className="grid grid-cols-1 md:grid-cols-2 gap-4"
      >
        <div>
          <RadioGroupItem
            value="creditCard"
            id="creditCard"
            className="peer sr-only"
          />
          <Label
            htmlFor="creditCard"
            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-gray-200 peer-data-[state=checked]:border-green-600 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
          >
            <div className="flex items-center justify-center space-x-2">
              <CreditCard className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Credit / Debit Card</span>
            </div>
            <div className="flex space-x-2 mt-2">
              <FaCcVisa className="h-6 w-6 text-blue-600" />
              <FaCcMastercard className="h-6 w-6 text-orange-600" />
              <FaCcAmex className="h-6 w-6 text-teal-600" />
            </div>
          </Label>
        </div>

        <div>
          <RadioGroupItem
            value="phonepe"
            id="phonepe"
            className="peer sr-only"
          />
          <Label
            htmlFor="phonepe"
            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-gray-200 peer-data-[state=checked]:border-green-600 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
          >
            <div className="flex items-center justify-center space-x-2">
              <Smartphone className="h-5 w-5 text-gray-600" />
              <span className="font-medium">PhonePe</span>
            </div>
            <div className="flex mt-2">
              <SiPhonepe className="h-6 w-6 text-indigo-600" />
            </div>
          </Label>
        </div>

        <div>
          <RadioGroupItem
            value="googlepay"
            id="googlepay"
            className="peer sr-only"
          />
          <Label
            htmlFor="googlepay"
            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-gray-200 peer-data-[state=checked]:border-green-600 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
          >
            <div className="flex items-center justify-center space-x-2">
              <Smartphone className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Google Pay</span>
            </div>
            <div className="flex mt-2">
              <FaGooglePay className="h-6 w-6 text-gray-700" />
            </div>
          </Label>
        </div>

        <div>
          <RadioGroupItem
            value="paytm"
            id="paytm"
            className="peer sr-only"
          />
          <Label
            htmlFor="paytm"
            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-gray-200 peer-data-[state=checked]:border-green-600 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
          >
            <div className="flex items-center justify-center space-x-2">
              <Smartphone className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Paytm</span>
            </div>
            <div className="flex mt-2">
              <SiPaytm className="h-6 w-6 text-blue-600" />
            </div>
          </Label>
        </div>

        <div className="md:col-span-2">
          <RadioGroupItem
            value="cashOnDelivery"
            id="cashOnDelivery"
            className="peer sr-only"
          />
          <Label
            htmlFor="cashOnDelivery"
            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-gray-200 peer-data-[state=checked]:border-green-600 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
          >
            <div className="flex items-center justify-center space-x-2">
              <Check className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Cash on Delivery</span>
            </div>
          </Label>
        </div>
      </RadioGroup>

      {error && (
        <div className="bg-red-50 p-3 rounded-md flex items-start text-sm text-red-600">
          <AlertCircle className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}

      {showDetails && paymentMethod === "creditCard" && (
        <Card>
          <CardContent className="p-4 space-y-4">
            <div>
              <Label htmlFor="cardNumber">Card Number</Label>
              <Input
                id="cardNumber"
                placeholder="1234 5678 9012 3456"
                value={cardNumber}
                onChange={handleCardNumberChange}
                maxLength={19}
              />
            </div>
            <div>
              <Label htmlFor="cardName">Name on Card</Label>
              <Input
                id="cardName"
                placeholder="John Smith"
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cardExpiry">Expiry Date (MM/YY)</Label>
                <Input
                  id="cardExpiry"
                  placeholder="MM/YY"
                  value={cardExpiry}
                  onChange={handleExpiryChange}
                  maxLength={5}
                />
              </div>
              <div>
                <Label htmlFor="cardCvc">CVC</Label>
                <Input
                  id="cardCvc"
                  placeholder="123"
                  value={cardCvc}
                  onChange={(e) => setCardCvc(e.target.value.replace(/\D/g, "").substring(0, 3))}
                  maxLength={3}
                  type="password"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {showDetails && ["phonepe", "googlepay", "paytm"].includes(paymentMethod) && (
        <Card>
          <CardContent className="p-4 space-y-4">
            <div>
              <Label htmlFor="upiId">UPI ID</Label>
              <Input
                id="upiId"
                placeholder="yourid@upi"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
              />
              <p className="text-sm text-gray-500 mt-1">
                Enter your UPI ID associated with {
                  paymentMethod === "phonepe" ? "PhonePe" : 
                  paymentMethod === "googlepay" ? "Google Pay" : "Paytm"
                }
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <Button 
        className="w-full bg-green-600 hover:bg-green-700" 
        onClick={validateAndProceed}
        disabled={isProcessing}
      >
        {isProcessing ? (
          <span className="flex items-center">
            <span className="animate-spin mr-2">⟳</span> Processing...
          </span>
        ) : (
          <span>Continue to Payment</span>
        )}
      </Button>
    </div>
  );
};

export default PaymentMethodSelector;