import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import {
  User,
  ShoppingCart,
  LogIn,
  Menu,
  X,
  Home,
  Search,
  ShoppingBag,
  PlusCircle,
  LogOut,
  UserCircle,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";

const Navbar = () => {
  const [location, navigate] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const { totalItems } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/buy?search=${encodeURIComponent(searchQuery)}`);
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <svg
              className="w-8 h-8 mr-2 text-green-600"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
              <path d="M14.5 2v4" />
              <path d="M20 2v4" />
              <path d="M8.5 2v4" />
              <path d="M3 8.5h4" />
              <path d="M3 14.5h4" />
              <path d="M3 20.5h4" />
            </svg>
            <span className="font-semibold text-xl text-green-700">EcoShop</span>
          </Link>

          {/* Search Bar - visible on desktop */}
          <form
            onSubmit={handleSearch}
            className="hidden md:flex flex-1 max-w-xl mx-8"
          >
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search eco-friendly products..."
                className="w-full pl-10 rounded-full border-green-200 focus:border-green-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-green-500" />
            </div>
            <Button
              type="submit"
              className="ml-2 bg-green-600 hover:bg-green-700 text-white"
            >
              Search
            </Button>
          </form>

          {/* Navigation Links - Desktop */}
          <nav className="hidden md:flex items-center space-x-4">
            <Link href="/buy">
              <Button
                variant="ghost"
                className="flex items-center gap-1 text-green-700 hover:text-green-800 hover:bg-green-50"
              >
                <ShoppingBag className="h-5 w-5" />
                <span>Shop</span>
              </Button>
            </Link>

            {user?.isSeller && (
              <Link href="/sell">
                <Button
                  variant="ghost"
                  className="flex items-center gap-1 text-green-700 hover:text-green-800 hover:bg-green-50"
                >
                  <PlusCircle className="h-5 w-5" />
                  <span>Sell</span>
                </Button>
              </Link>
            )}

            <Link href="/cart">
              <Button
                variant="ghost"
                className="relative flex items-center gap-1 text-green-700 hover:text-green-800 hover:bg-green-50"
              >
                <ShoppingCart className="h-5 w-5" />
                <span>Cart</span>
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Button>
            </Link>

            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center gap-1 text-green-700 hover:text-green-800 hover:bg-green-50"
                  >
                    <User className="h-5 w-5" />
                    <span>{user?.username || "Account"}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => navigate("/profile")}>
                    <UserCircle className="h-4 w-4 mr-2" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => logout()}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/login">
                <Button
                  variant="ghost"
                  className="flex items-center gap-1 text-green-700 hover:text-green-800 hover:bg-green-50"
                >
                  <LogIn className="h-5 w-5" />
                  <span>Login</span>
                </Button>
              </Link>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center space-x-2">
            <Link href="/cart">
              <Button
                variant="ghost"
                size="icon"
                className="relative text-green-700"
              >
                <ShoppingCart className="h-6 w-6" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMobileMenu}
              aria-label="Toggle menu"
              className="text-green-700"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile search - shown below navbar on mobile */}
        <div className="mt-3 md:hidden">
          <form onSubmit={handleSearch} className="flex">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search eco-friendly products..."
                className="w-full pl-10 rounded-full border-green-200"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-green-500" />
            </div>
            <Button
              type="submit"
              size="sm"
              className="ml-2 bg-green-600 hover:bg-green-700 text-white"
            >
              Search
            </Button>
          </form>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 absolute w-full left-0 shadow-lg z-50">
          <div className="container mx-auto px-4 py-3 flex flex-col space-y-2">
            <Link href="/" onClick={closeMobileMenu}>
              <Button
                variant="ghost"
                className="flex items-center justify-start w-full gap-2 text-green-700"
              >
                <Home className="h-5 w-5" />
                <span>Home</span>
              </Button>
            </Link>
            <Link href="/buy" onClick={closeMobileMenu}>
              <Button
                variant="ghost"
                className="flex items-center justify-start w-full gap-2 text-green-700"
              >
                <ShoppingBag className="h-5 w-5" />
                <span>Shop</span>
              </Button>
            </Link>
            {user?.isSeller && (
              <Link href="/sell" onClick={closeMobileMenu}>
                <Button
                  variant="ghost"
                  className="flex items-center justify-start w-full gap-2 text-green-700"
                >
                  <PlusCircle className="h-5 w-5" />
                  <span>Sell</span>
                </Button>
              </Link>
            )}
            {isAuthenticated ? (
              <>
                <Link href="/profile" onClick={closeMobileMenu}>
                  <Button
                    variant="ghost"
                    className="flex items-center justify-start w-full gap-2 text-green-700"
                  >
                    <UserCircle className="h-5 w-5" />
                    <span>Profile</span>
                  </Button>
                </Link>
                <Button
                  variant="ghost"
                  className="flex items-center justify-start w-full gap-2 text-green-700"
                  onClick={() => {
                    logout();
                    closeMobileMenu();
                  }}
                >
                  <LogOut className="h-5 w-5" />
                  <span>Logout</span>
                </Button>
              </>
            ) : (
              <Link href="/login" onClick={closeMobileMenu}>
                <Button
                  variant="ghost"
                  className="flex items-center justify-start w-full gap-2 text-green-700"
                >
                  <LogIn className="h-5 w-5" />
                  <span>Login</span>
                </Button>
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
