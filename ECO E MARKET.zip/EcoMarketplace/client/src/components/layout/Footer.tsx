import { Link } from "wouter";
import { Facebook, Instagram, Twitter, Linkedin, Mail, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-green-50 text-green-900 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">EcoShop</h3>
            <p className="text-sm mb-4">
              Your marketplace for eco-friendly and sustainable products. Join us in
              making a positive impact on the environment.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-green-700 hover:text-green-500 transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={20} />
              </a>
              <a
                href="#"
                className="text-green-700 hover:text-green-500 transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a
                href="#"
                className="text-green-700 hover:text-green-500 transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
              <a
                href="#"
                className="text-green-700 hover:text-green-500 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="hover:text-green-500 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/buy" className="hover:text-green-500 transition-colors">
                  Shop
                </Link>
              </li>
              <li>
                <Link href="/sell" className="hover:text-green-500 transition-colors">
                  Sell
                </Link>
              </li>
              <li>
                <Link href="/cart" className="hover:text-green-500 transition-colors">
                  Cart
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Categories</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link
                  href="/buy?category=Sustainable Home"
                  className="hover:text-green-500 transition-colors"
                >
                  Sustainable Home
                </Link>
              </li>
              <li>
                <Link
                  href="/buy?category=Eco-Friendly Kitchen"
                  className="hover:text-green-500 transition-colors"
                >
                  Eco-Friendly Kitchen
                </Link>
              </li>
              <li>
                <Link
                  href="/buy?category=Zero Waste"
                  className="hover:text-green-500 transition-colors"
                >
                  Zero Waste
                </Link>
              </li>
              <li>
                <Link
                  href="/buy?category=Eco Packaging"
                  className="hover:text-green-500 transition-colors"
                >
                  Eco Packaging
                </Link>
              </li>
              <li>
                <Link
                  href="/buy?category=Energy Efficient"
                  className="hover:text-green-500 transition-colors"
                >
                  Energy Efficient
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start space-x-2">
                <Phone size={18} className="mt-0.5 text-green-600" />
                <span>+91 7036317778</span>
              </li>
              <li className="flex items-start space-x-2">
                <Mail size={18} className="mt-0.5 text-green-600" />
                <span>santhoshkumarreddy@ecoshop.com</span>
              </li>
              <li>
                <p>M. Santhosh Kumar Reddy</p>
                <p>Eco Marketplace Enterprises</p>
                <p>Green Tech Park, Sustainable Boulevard</p>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-green-200 mt-8 pt-6 text-center text-sm">
          <p>
            &copy; {new Date().getFullYear()} EcoShop Marketplace. All rights
            reserved.
          </p>
          <p className="mt-2">
            <Link href="#" className="hover:text-green-500 transition-colors mr-4">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:text-green-500 transition-colors mr-4">
              Terms of Service
            </Link>
            <Link href="#" className="hover:text-green-500 transition-colors">
              Sustainability Pledge
            </Link>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
