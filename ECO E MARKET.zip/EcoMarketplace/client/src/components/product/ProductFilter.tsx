import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Filter, ChevronDown, ChevronUp } from "lucide-react";
import { useLocation } from "wouter";

interface ProductFilterProps {
  onFilterChange?: (filters: {
    category?: string;
    minPrice?: number;
    maxPrice?: number;
  }) => void;
  initialFilters?: {
    category?: string;
    minPrice?: number;
    maxPrice?: number;
  };
}

const ProductFilter = ({
  onFilterChange,
  initialFilters = {},
}: ProductFilterProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(
    initialFilters.category
  );
  const [priceRange, setPriceRange] = useState<[number, number]>([
    initialFilters.minPrice || 0,
    initialFilters.maxPrice || 200,
  ]);
  const [expanded, setExpanded] = useState({
    categories: true,
    price: true,
  });
  const [, setLocation] = useLocation();

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ["/api/products/categories"],
  });

  useEffect(() => {
    if (onFilterChange) {
      onFilterChange({
        category: selectedCategory,
        minPrice: priceRange[0],
        maxPrice: priceRange[1],
      });
    }
  }, [selectedCategory, priceRange, onFilterChange]);

  const toggleSection = (section: "categories" | "price") => {
    setExpanded({
      ...expanded,
      [section]: !expanded[section],
    });
  };

  const handleCategoryChange = (category: string) => {
    if (selectedCategory === category) {
      setSelectedCategory(undefined);
    } else {
      setSelectedCategory(category);
    }
  };

  const handlePriceChange = (values: number[]) => {
    setPriceRange([values[0], values[1]]);
  };

  const handleClearFilters = () => {
    setSelectedCategory(undefined);
    setPriceRange([0, 200]);
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium text-lg flex items-center">
          <Filter className="w-5 h-5 mr-2" />
          Filters
        </h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleClearFilters}
          className="text-sm text-gray-500 hover:text-gray-700"
        >
          Clear All
        </Button>
      </div>

      {/* Categories */}
      <div className="mb-6">
        <div
          className="flex items-center justify-between cursor-pointer mb-2"
          onClick={() => toggleSection("categories")}
        >
          <h4 className="font-medium">Categories</h4>
          {expanded.categories ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </div>
        {expanded.categories && (
          <div className="space-y-2 mt-2">
            {categories.map((category: string) => (
              <div key={category} className="flex items-center space-x-2">
                <Checkbox
                  id={`category-${category}`}
                  checked={selectedCategory === category}
                  onCheckedChange={() => handleCategoryChange(category)}
                />
                <Label
                  htmlFor={`category-${category}`}
                  className="text-sm cursor-pointer"
                >
                  {category}
                </Label>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Price Range */}
      <div>
        <div
          className="flex items-center justify-between cursor-pointer mb-2"
          onClick={() => toggleSection("price")}
        >
          <h4 className="font-medium">Price Range</h4>
          {expanded.price ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </div>
        {expanded.price && (
          <div className="space-y-4 mt-2">
            <Slider
              defaultValue={priceRange}
              min={0}
              max={200}
              step={1}
              onValueChange={handlePriceChange}
              className="my-4"
            />
            <div className="flex items-center justify-between">
              <div className="bg-gray-100 px-2 py-1 rounded text-sm">
                ${priceRange[0]}
              </div>
              <div className="bg-gray-100 px-2 py-1 rounded text-sm">
                ${priceRange[1]}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Apply filter button for mobile */}
      <Button
        className="w-full mt-6 bg-green-600 hover:bg-green-700 md:hidden"
        onClick={() =>
          setLocation(
            `/buy?${selectedCategory ? `category=${selectedCategory}&` : ""}minPrice=${
              priceRange[0]
            }&maxPrice=${priceRange[1]}`
          )
        }
      >
        Apply Filters
      </Button>
    </div>
  );
};

export default ProductFilter;
