import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Star, Heart, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  ecoRating: number;
}

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart, isLoading: isCartLoading } = useCart();
  const { isAuthenticated } = useAuth();
  const [_, navigate] = useLocation();
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to add items to your cart",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }

    addToCart(product.id, 1);
  };

  // Generate eco rating stars
  const renderEcoRating = () => {
    const stars = [];
    for (let i = 0; i < 5; i++) {
      stars.push(
        <Star
          key={i}
          size={16}
          className={`${
            i < product.ecoRating ? "text-green-500 fill-green-500" : "text-gray-300"
          }`}
        />
      );
    }
    return stars;
  };

  return (
    <Card className="h-full flex flex-col overflow-hidden group hover:shadow-md transition-shadow">
      <Link href={`/products/${product.id}`}>
        <CardHeader className="p-0 relative overflow-hidden aspect-square">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <Badge className="absolute top-2 right-2 bg-green-500 hover:bg-green-600">
            {product.category}
          </Badge>
        </CardHeader>
        <CardContent className="p-4 flex-grow">
          <div className="flex items-center space-x-1 mb-2">
            {renderEcoRating()}
            <span className="text-xs ml-1 text-gray-500">Eco Rating</span>
          </div>
          <h3 className="font-medium text-gray-900 mb-1 line-clamp-2">
            {product.name}
          </h3>
          <p className="text-gray-600 text-sm mb-2 line-clamp-2">
            {product.description.substring(0, 100)}
            {product.description.length > 100 && "..."}
          </p>
          <div className="text-lg font-semibold text-green-700">
            ${product.price.toFixed(2)}
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0 mt-auto flex gap-2">
          <Button
            className="w-full bg-green-600 hover:bg-green-700 text-white"
            size="sm"
            onClick={handleAddToCart}
            disabled={isCartLoading}
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            Add to Cart
          </Button>
        </CardFooter>
      </Link>
    </Card>
  );
};

export default ProductCard;
