import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Leaf } from "lucide-react";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  ecoRating: number;
  stock: number;
  ecoDescription?: string;
}

interface RecommendedProductsProps {
  products: Product[];
  isLoading: boolean;
  title?: string;
  description?: string;
}

const RecommendedProducts = ({ 
  products, 
  isLoading,
  title = "Recommended For You",
  description = "Based on your browsing history and preferences, you might also like these eco-friendly products."
}: RecommendedProductsProps) => {
  if (isLoading) {
    return (
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-2">{title}</h2>
        <p className="text-gray-600 mb-6">{description}</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <div className="aspect-square bg-gray-200 animate-pulse" />
              <CardContent className="p-4">
                <Skeleton className="h-5 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2 mb-4" />
                <Skeleton className="h-6 w-1/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    );
  }

  if (!products || products.length === 0) {
    return null;
  }

  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold mb-2">{title}</h2>
      <p className="text-gray-600 mb-6">{description}</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <Link key={product.id} href={`/products/${product.id}`}>
            <a className="group">
              <Card className="overflow-hidden h-full transition-transform duration-300 transform group-hover:-translate-y-1 cursor-pointer">
                <div className="aspect-square overflow-hidden bg-gray-50">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  {product.ecoRating > 4 && (
                    <Badge 
                      className="absolute top-2 right-2 bg-green-500 text-white"
                    >
                      <Leaf className="h-3 w-3 mr-1" /> Eco-Friendly
                    </Badge>
                  )}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium text-lg line-clamp-1 group-hover:text-green-700 transition-colors">
                    {product.name}
                  </h3>
                  <div className="text-gray-500 text-sm mb-2">
                    {product.category}
                  </div>
                  <div className="font-bold text-green-700">
                    ${product.price.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </a>
          </Link>
        ))}
      </div>
    </section>
  );
};

export default RecommendedProducts;