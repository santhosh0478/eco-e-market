import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Home, Utensils, Sparkles, ShoppingBag, Recycle, Package, Zap, Repeat, Leaf, Droplet } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const CategorySection = () => {
  // Fetch categories from the API
  const { data: categories = [] } = useQuery({
    queryKey: ["/api/products/categories"],
  });

  // Map of category icons
  const categoryIcons: Record<string, JSX.Element> = {
    "Sustainable Home": <Home className="h-8 w-8 text-green-600" />,
    "Eco-Friendly Kitchen": <Utensils className="h-8 w-8 text-green-600" />,
    "Green Beauty": <Sparkles className="h-8 w-8 text-green-600" />,
    "Sustainable Fashion": <ShoppingBag className="h-8 w-8 text-green-600" />,
    "Zero Waste": <Recycle className="h-8 w-8 text-green-600" />,
    "Eco Packaging": <Package className="h-8 w-8 text-green-600" />,
    "Energy Efficient": <Zap className="h-8 w-8 text-green-600" />,
    "Recycled Products": <Repeat className="h-8 w-8 text-green-600" />,
    "Organic Living": <Leaf className="h-8 w-8 text-green-600" />,
    "Plant-based": <Droplet className="h-8 w-8 text-green-600" />,
  };

  return (
    <section className="py-10">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-3">Shop by Category</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Explore our curated collection of eco-friendly products across various categories
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {categories.map((category: string) => (
          <Link key={category} href={`/buy?category=${encodeURIComponent(category)}`}>
            <Card className="hover:shadow-md transition-shadow border-green-100 cursor-pointer h-full">
              <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                <div className="mb-3 bg-green-50 p-3 rounded-full">
                  {categoryIcons[category] || <Leaf className="h-8 w-8 text-green-600" />}
                </div>
                <h3 className="font-medium text-gray-900">{category}</h3>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  );
};

export default CategorySection;
