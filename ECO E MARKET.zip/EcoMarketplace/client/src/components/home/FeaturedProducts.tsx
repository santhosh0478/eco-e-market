import { useEffect, useState } from "react";
import ProductGrid from "@/components/product/ProductGrid";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ChevronRight } from "lucide-react";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  ecoRating: number;
}

interface FeaturedProductsProps {
  products: Product[];
  isLoading: boolean;
}

const FeaturedProducts = ({ products, isLoading }: FeaturedProductsProps) => {
  const [displayCount, setDisplayCount] = useState(4);

  // Handle window resize to adjust display count
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) {
        setDisplayCount(2); // Mobile view
      } else if (window.innerWidth < 1024) {
        setDisplayCount(3); // Tablet view
      } else {
        setDisplayCount(4); // Desktop view
      }
    };

    handleResize(); // Initial check
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const displayedProducts = products?.slice(0, displayCount) || [];

  return (
    <section className="py-10">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Products</h2>
          <p className="text-gray-600">
            Our selection of top eco-friendly products
          </p>
        </div>
        <Link href="/buy">
          <Button variant="outline" className="text-green-700 border-green-200 hover:bg-green-50">
            View All <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        </Link>
      </div>

      <ProductGrid products={displayedProducts} isLoading={isLoading} />
    </section>
  );
};

export default FeaturedProducts;
