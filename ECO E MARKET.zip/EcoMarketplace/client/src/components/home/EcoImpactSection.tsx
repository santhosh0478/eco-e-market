import { Card, CardContent } from "@/components/ui/card";
import { Leaf, Droplet, Wind, Sparkles } from "lucide-react";

const EcoImpactSection = () => {
  return (
    <section className="py-12">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-gray-900 mb-3">
          Your Positive Impact
        </h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Every purchase from our eco-friendly marketplace helps contribute to environmental sustainability and a healthier planet
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-green-100">
          <CardContent className="p-6">
            <div className="bg-green-50 p-3 rounded-full w-fit mb-4">
              <Leaf className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-xl mb-2">Reduced Carbon Footprint</h3>
            <p className="text-gray-600">
              Our eco-friendly products have a significantly lower carbon footprint compared to conventional alternatives
            </p>
          </CardContent>
        </Card>

        <Card className="border-green-100">
          <CardContent className="p-6">
            <div className="bg-green-50 p-3 rounded-full w-fit mb-4">
              <Droplet className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-xl mb-2">Water Conservation</h3>
            <p className="text-gray-600">
              Products made with sustainable manufacturing processes that use less water and reduce pollution
            </p>
          </CardContent>
        </Card>

        <Card className="border-green-100">
          <CardContent className="p-6">
            <div className="bg-green-50 p-3 rounded-full w-fit mb-4">
              <Wind className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-xl mb-2">Waste Reduction</h3>
            <p className="text-gray-600">
              Sustainable packaging and zero-waste options help reduce landfill waste and ocean plastic
            </p>
          </CardContent>
        </Card>

        <Card className="border-green-100">
          <CardContent className="p-6">
            <div className="bg-green-50 p-3 rounded-full w-fit mb-4">
              <Sparkles className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-xl mb-2">Better Health</h3>
            <p className="text-gray-600">
              Products free from harmful chemicals and toxins that are better for you and the environment
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default EcoImpactSection;
