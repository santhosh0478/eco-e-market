import { useState } from "react";
import { Link } from "wouter";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Trash, Plus, Minus } from "lucide-react";
import { Input } from "@/components/ui/input";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  stock: number;
}

interface CartItemProps {
  item: {
    id: number;
    quantity: number;
    product: Product;
  };
}

const CartItem = ({ item }: CartItemProps) => {
  const { updateCartItem, removeFromCart, isLoading } = useCart();
  const [quantity, setQuantity] = useState(item.quantity);

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuantity = parseInt(e.target.value);
    if (isNaN(newQuantity) || newQuantity < 1) return;
    if (newQuantity > item.product.stock) return;
    
    setQuantity(newQuantity);
  };

  const handleUpdateQuantity = () => {
    if (quantity !== item.quantity) {
      updateCartItem(item.id, quantity);
    }
  };

  const handleIncrement = () => {
    if (quantity < item.product.stock) {
      const newQuantity = quantity + 1;
      setQuantity(newQuantity);
      updateCartItem(item.id, newQuantity);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      const newQuantity = quantity - 1;
      setQuantity(newQuantity);
      updateCartItem(item.id, newQuantity);
    }
  };

  const handleRemove = () => {
    removeFromCart(item.id);
  };

  const subtotal = item.product.price * quantity;

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center py-4 border-b border-gray-200">
      {/* Product Image */}
      <div className="w-24 h-24 flex-shrink-0 mr-4 mb-3 sm:mb-0 overflow-hidden rounded">
        <Link href={`/products/${item.product.id}`}>
          <img
            src={item.product.imageUrl}
            alt={item.product.name}
            className="w-full h-full object-cover"
          />
        </Link>
      </div>

      {/* Product Info */}
      <div className="flex-grow sm:ml-2">
        <Link href={`/products/${item.product.id}`}>
          <h3 className="font-medium text-gray-900 hover:text-green-600 transition-colors">
            {item.product.name}
          </h3>
        </Link>
        <p className="text-sm text-gray-500 mb-1">
          Category: {item.product.category}
        </p>
        <p className="text-green-600 font-medium">
          ${item.product.price.toFixed(2)}
        </p>
      </div>

      {/* Quantity Controls */}
      <div className="flex items-center mt-3 sm:mt-0 sm:ml-4">
        <div className="flex items-center border rounded overflow-hidden">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-none"
            onClick={handleDecrement}
            disabled={quantity <= 1 || isLoading}
          >
            <Minus className="h-3 w-3" />
          </Button>
          <Input
            type="number"
            min="1"
            max={item.product.stock}
            value={quantity}
            onChange={handleQuantityChange}
            onBlur={handleUpdateQuantity}
            className="w-12 h-8 text-center p-0 border-0"
          />
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-none"
            onClick={handleIncrement}
            disabled={quantity >= item.product.stock || isLoading}
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {/* Subtotal */}
      <div className="text-right ml-auto mt-3 sm:mt-0 sm:ml-6 flex flex-col items-end">
        <span className="font-medium text-gray-900">
          ${subtotal.toFixed(2)}
        </span>
        <Button
          variant="ghost"
          size="sm"
          className="text-red-500 hover:text-red-700 hover:bg-red-50 p-0 h-auto mt-1"
          onClick={handleRemove}
          disabled={isLoading}
        >
          <Trash className="h-4 w-4 mr-1" />
          <span className="text-xs">Remove</span>
        </Button>
      </div>
    </div>
  );
};

export default CartItem;
